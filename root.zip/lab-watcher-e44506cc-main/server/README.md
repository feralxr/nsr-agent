# Lab Monitor — Server

Relay + web viewer host. Runs on the lab's designated "server" PC (the one
with a static LAN IP).

## Setup

1. Install [Bun](https://bun.sh) (or Node.js 20+).
2. Build the viewer once (from the repo root, not this folder):
   ```
   bun install
   bun run build
   ```
   This produces `../dist/` which the server serves.
3. Install server deps and start:
   ```
   cd server
   bun install
   bun run start
   ```
   Default port is 8080. Override with `PORT=9000 bun run start`.

## Firewall

Open TCP 8080 in Windows Defender Firewall (inbound) for Private/Domain profiles.

```powershell
New-NetFirewallRule -DisplayName "Lab Monitor" -Direction Inbound -Protocol TCP -LocalPort 8080 -Action Allow -Profile Private,Domain
```

## Run as a Windows service (optional, recommended)

Use [NSSM](https://nssm.cc):

```
nssm install LabMonitorServer "C:\Program Files\bun\bun.exe" "run C:\lab-monitor\server\server.js"
nssm set LabMonitorServer AppDirectory "C:\lab-monitor\server"
nssm set LabMonitorServer Start SERVICE_AUTO_START
nssm start LabMonitorServer
```

## Open the viewer

Any browser on the LAN: `http://<server-ip>:8080/`
