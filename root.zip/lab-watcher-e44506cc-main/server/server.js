// Lab Monitor relay server.
// - Serves the built viewer web UI (../dist) at /
// - /agent  WebSocket : client agents connect here, register, stream H.264 + JPEG
// - /viewer WebSocket : browser viewers list clients + subscribe to a stream / snapshots
//
// Binary protocol (agent -> server):
//   first byte is a tag:
//     0x01  H.264 NAL (Annex-B) -> fanned out to stream subscribers
//     0x02  JPEG snapshot        -> fanned out to snapshot subscribers
//   server strips the tag before forwarding to viewers.
//
// Run:  bun install && bun run server.js
// Or:   node server.js  (Node 20+)

import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { extname, join, normalize, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { WebSocketServer } from "ws";

const PORT = Number(process.env.PORT || 8080);
const __dirname = fileURLToPath(new URL(".", import.meta.url));
const STATIC_DIR = resolve(__dirname, "..", "dist");

const TAG_H264 = 0x01;
const TAG_JPEG = 0x02;

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js":   "text/javascript; charset=utf-8",
  ".css":  "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg":  "image/svg+xml",
  ".png":  "image/png",
  ".jpg":  "image/jpeg",
  ".ico":  "image/x-icon",
  ".woff2": "font/woff2",
};

// ------- state -------
// agents: clientId -> {
//   ws, label, hostname, ip, connectedAt, lastSeen,
//   streamSubs:Set<ws>, snapSubs:Set<ws>,
//   streaming:bool, streamFps, streamBitrate,
//   snapshotting:bool, snapshotFps,
// }
const agents = new Map();
// viewers: ws -> { listSubscribed:bool, subscribedTo:string|null, snapSubs:Set<string> }
const viewers = new Map();

function agentList() {
  return [...agents.entries()].map(([id, a]) => ({
    id, label: a.label, hostname: a.hostname, ip: a.ip,
    connectedAt: a.connectedAt, lastSeen: a.lastSeen,
  }));
}

function broadcastList() {
  const payload = JSON.stringify({ type: "clients", clients: agentList() });
  for (const [ws, v] of viewers) if (v.listSubscribed && ws.readyState === 1) ws.send(payload);
}

// ------- http (static) -------
const server = createServer(async (req, res) => {
  if (req.url === "/api/clients") {
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify(agentList()));
    return;
  }
  try {
    let urlPath = decodeURIComponent((req.url || "/").split("?")[0]);
    if (urlPath === "/") urlPath = "/index.html";
    const filePath = normalize(join(STATIC_DIR, urlPath));
    if (!filePath.startsWith(STATIC_DIR)) { res.writeHead(403).end(); return; }
    let final = filePath;
    try { await stat(final); } catch { final = join(STATIC_DIR, "index.html"); }
    const body = await readFile(final);
    res.writeHead(200, { "content-type": MIME[extname(final)] || "application/octet-stream" });
    res.end(body);
  } catch {
    res.writeHead(404, { "content-type": "text/plain" }).end("Not found. Build the viewer first: bun run build");
  }
});

// ------- websockets -------
const wss = new WebSocketServer({ noServer: true });

server.on("upgrade", (req, socket, head) => {
  const url = req.url || "";
  if (url === "/agent" || url === "/viewer") {
    wss.handleUpgrade(req, socket, head, (ws) => {
      ws._kind = url === "/agent" ? "agent" : "viewer";
      ws._ip = req.socket.remoteAddress?.replace(/^::ffff:/, "") || "?";
      wss.emit("connection", ws, req);
    });
  } else {
    socket.destroy();
  }
});

wss.on("connection", (ws) => {
  if (ws._kind === "agent") handleAgent(ws);
  else handleViewer(ws);
});

// --- helpers to (re)issue agent commands with current desired parameters ---

function ensureStreaming(a) {
  if (a.streamSubs.size === 0) {
    if (a.streaming) {
      a.streaming = false;
      a.ws.send(JSON.stringify({ type: "stop_stream" }));
    }
    return;
  }
  if (!a.streaming) {
    a.streaming = true;
    a.ws.send(JSON.stringify({
      type: "start_stream", fps: a.streamFps, bitrate: a.streamBitrate,
    }));
  }
}

function ensureSnapshotting(a) {
  if (a.snapSubs.size === 0) {
    if (a.snapshotting) {
      a.snapshotting = false;
      a.ws.send(JSON.stringify({ type: "stop_snapshots" }));
    }
    return;
  }
  // Use the MAX requested fps across snapshot subscribers.
  let fps = 0;
  for (const s of a.snapSubs) fps = Math.max(fps, s._snapFps || 2);
  if (!a.snapshotting || a.snapshotFps !== fps) {
    a.snapshotting = true;
    a.snapshotFps = fps;
    a.ws.send(JSON.stringify({ type: "start_snapshots", fps }));
  }
}

function handleAgent(ws) {
  let clientId = null;
  ws.on("message", (data, isBinary) => {
    if (!isBinary) {
      try {
        const msg = JSON.parse(data.toString());
        if (msg.type === "hello") {
          clientId = msg.clientId || `${msg.hostname}-${ws._ip}`;
          const label = (msg.label && String(msg.label).trim()) || msg.hostname || clientId;
          agents.set(clientId, {
            ws, label, hostname: msg.hostname || clientId, ip: ws._ip,
            connectedAt: Date.now(), lastSeen: Date.now(),
            streamSubs: new Set(), snapSubs: new Set(),
            streaming: false, streamFps: 30, streamBitrate: 3_000_000,
            snapshotting: false, snapshotFps: 2,
          });
          console.log(`[agent] connect ${clientId} (${label}) @ ${ws._ip}`);
          broadcastList();
        } else if (msg.type === "pong") {
          const a = agents.get(clientId);
          if (a) a.lastSeen = Date.now();
        } else if (msg.type === "apps") {
          // Fan out the apps snapshot to viewers watching this client's tile.
          const a = agents.get(clientId);
          if (!a) return;
          a.lastApps = { apps: msg.apps || [], foreground: msg.foreground || null, at: Date.now() };
          const out = JSON.stringify({
            type: "apps", clientId,
            apps: a.lastApps.apps, foreground: a.lastApps.foreground,
          });
          for (const v of a.snapSubs) if (v.readyState === 1) v.send(out);
        }
      } catch { /* ignore */ }
      return;
    }
    // Binary: TAG || payload
    const a = clientId && agents.get(clientId);
    if (!a || data.length < 1) return;
    a.lastSeen = Date.now();
    const tag = data[0];
    const payload = data.slice(1);
    const targets = tag === TAG_JPEG ? a.snapSubs : a.streamSubs;
    for (const v of targets) {
      if (v.readyState !== 1) continue;
      if (tag === TAG_JPEG) {
        // Wrap JPEG so viewer can multiplex per-client in grid mode.
        v.send(JSON.stringify({ type: "snapshot", clientId, size: payload.length }));
        v.send(payload, { binary: true });
      } else {
        v.send(payload, { binary: true });
      }
    }
  });

  const ping = setInterval(() => {
    if (ws.readyState === 1) ws.send(JSON.stringify({ type: "ping" }));
  }, 10_000);

  ws.on("close", () => {
    clearInterval(ping);
    if (clientId && agents.has(clientId)) {
      const a = agents.get(clientId);
      for (const v of [...a.streamSubs, ...a.snapSubs]) {
        if (v.readyState === 1)
          v.send(JSON.stringify({ type: "client_offline", clientId }));
      }
      agents.delete(clientId);
      console.log(`[agent] disconnect ${clientId}`);
      broadcastList();
    }
  });
}

function handleViewer(ws) {
  ws._snapFps = 2;
  viewers.set(ws, { listSubscribed: false, subscribedTo: null, snapSubs: new Set() });

  ws.on("message", (data) => {
    try {
      const msg = JSON.parse(data.toString());
      const v = viewers.get(ws);

      if (msg.type === "list_subscribe") {
        v.listSubscribed = true;
        ws.send(JSON.stringify({ type: "clients", clients: agentList() }));
        return;
      }

      // Full H.264 stream subscription (detail view). One per viewer.
      if (msg.type === "subscribe") {
        if (v.subscribedTo) {
          const prev = agents.get(v.subscribedTo);
          if (prev) { prev.streamSubs.delete(ws); ensureStreaming(prev); }
        }
        const a = agents.get(msg.clientId);
        if (!a) { ws.send(JSON.stringify({ type: "client_offline", clientId: msg.clientId })); return; }
        v.subscribedTo = msg.clientId;
        a.streamSubs.add(ws);
        if (typeof msg.fps === "number") a.streamFps = Math.max(5, Math.min(60, msg.fps));
        if (typeof msg.bitrate === "number") a.streamBitrate = msg.bitrate;
        // Restart stream with new params.
        if (a.streaming) {
          a.streaming = false;
          a.ws.send(JSON.stringify({ type: "stop_stream" }));
        }
        ensureStreaming(a);
        ws.send(JSON.stringify({ type: "stream_started", clientId: msg.clientId }));
        return;
      }

      // CCTV grid snapshot subscription. Many per viewer (one per tile).
      if (msg.type === "subscribe_snapshot") {
        const a = agents.get(msg.clientId);
        if (!a) { ws.send(JSON.stringify({ type: "client_offline", clientId: msg.clientId })); return; }
        ws._snapFps = Math.max(1, Math.min(15, msg.fps || 2));
        if (!v.snapSubs.has(msg.clientId)) {
          v.snapSubs.add(msg.clientId);
          a.snapSubs.add(ws);
        }
        ensureSnapshotting(a);
        // Push last known apps immediately so the tile doesn't stay blank
        // until the next 1.5s agent tick.
        if (a.lastApps) {
          ws.send(JSON.stringify({
            type: "apps", clientId: msg.clientId,
            apps: a.lastApps.apps, foreground: a.lastApps.foreground,
          }));
        }
        return;
      }

      if (msg.type === "unsubscribe_snapshot") {
        const a = agents.get(msg.clientId);
        v.snapSubs.delete(msg.clientId);
        if (a) { a.snapSubs.delete(ws); ensureSnapshotting(a); }
        return;
      }

      if (msg.type === "set_snapshot_fps") {
        ws._snapFps = Math.max(1, Math.min(15, msg.fps || 2));
        for (const id of v.snapSubs) {
          const a = agents.get(id);
          if (a) ensureSnapshotting(a);
        }
        return;
      }
    } catch { /* ignore */ }
  });

  ws.on("close", () => {
    const v = viewers.get(ws);
    if (!v) return;
    if (v.subscribedTo) {
      const a = agents.get(v.subscribedTo);
      if (a) { a.streamSubs.delete(ws); ensureStreaming(a); }
    }
    for (const id of v.snapSubs) {
      const a = agents.get(id);
      if (a) { a.snapSubs.delete(ws); ensureSnapshotting(a); }
    }
    viewers.delete(ws);
  });
}

server.listen(PORT, () => {
  console.log(`Lab Monitor server on http://0.0.0.0:${PORT}`);
  console.log(`Open http://<this-pc-lan-ip>:${PORT}/ from any browser on the LAN.`);
});
