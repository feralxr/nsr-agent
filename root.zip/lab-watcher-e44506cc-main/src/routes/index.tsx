import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  DEFAULT_SETTINGS, getServerHttpUrl, getServerWsUrl,
  loadSettings, saveSettings, setServerUrl, type ViewerSettings,
} from "@/lib/server-config";
import { getCctvSocket, type AppsSnapshot } from "@/lib/cctv-socket";
import { compileFilter, isFilteredProc, prettyProcName } from "@/lib/app-filter";
import {
  CARD_H, CARD_W, GRID, loadLayout, nextFreeSlot, saveLayout, snap,
  type Layout, type Pos,
} from "@/lib/pc-layout";
import {
  BASE_COLOR_PRESETS, applyBaseColor, loadBaseColor, saveBaseColor,
} from "@/lib/base-color";

export const Route = createFileRoute("/")({
  component: LabDashboard,
  head: () => ({
    meta: [
      { title: "Lab Monitor — Console" },
      { name: "description", content: "Live console for every lab PC. Arrange PCs on a canvas or watch every screen at once in grid view." },
    ],
  }),
});

interface ClientInfo {
  id: string;
  label?: string;
  hostname: string;
  ip: string;
  connectedAt: number;
  lastSeen: number;
}

type Mode = "layout" | "grid";
type Status = "connecting" | "online" | "offline";

function LabDashboard() {
  const [clients, setClients] = useState<ClientInfo[]>([]);
  const [status, setStatus] = useState<Status>("connecting");
  const [layout, setLayout] = useState<Layout>(() => loadLayout());
  const [editing, setEditing] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [mode, setMode] = useState<Mode>("layout");
  const [settings, setSettings] = useState<ViewerSettings>(() => loadSettings());
  const canvasRef = useRef<HTMLDivElement | null>(null);
  const [baseColor, setBaseColorState] = useState<string>(() => loadBaseColor());

  useEffect(() => { applyBaseColor(baseColor); }, [baseColor]);
  const setBaseColor = (hex: string) => { saveBaseColor(hex); setBaseColorState(hex); };

  useEffect(() => {
    let ws: WebSocket | null = null;
    let retry: ReturnType<typeof setTimeout> | null = null;
    let stopped = false;

    const connect = () => {
      if (stopped) return;
      setStatus("connecting");
      try { ws = new WebSocket(`${getServerWsUrl()}/viewer`); }
      catch { retry = setTimeout(connect, 2000); return; }
      ws.onopen = () => { setStatus("online"); ws?.send(JSON.stringify({ type: "list_subscribe" })); };
      ws.onmessage = (ev) => {
        try {
          const m = JSON.parse(ev.data);
          if (m.type === "clients") setClients(m.clients);
        } catch { /* noop */ }
      };
      ws.onclose = () => { setStatus("offline"); if (!stopped) retry = setTimeout(connect, 2000); };
      ws.onerror = () => ws?.close();
    };
    connect();
    return () => { stopped = true; if (retry) clearTimeout(retry); ws?.close(); };
  }, []);

  useEffect(() => {
    if (!clients.length) return;
    const cw = canvasRef.current?.clientWidth ?? 1200;
    setLayout((prev) => {
      let changed = false;
      const next = { ...prev };
      const taken: Pos[] = Object.values(next);
      for (const c of clients) {
        if (!next[c.id]) {
          next[c.id] = nextFreeSlot(taken, cw);
          taken.push(next[c.id]);
          changed = true;
        }
      }
      if (changed) saveLayout(next);
      return changed ? next : prev;
    });
  }, [clients]);

  const updatePos = useCallback((id: string, pos: Pos) => {
    setLayout((prev) => {
      const next = { ...prev, [id]: pos };
      saveLayout(next);
      return next;
    });
  }, []);

  const clearLayout = () => {
    if (!confirm("Reset all PC positions?")) return;
    saveLayout({});
    setLayout({});
  };

  const onlineIds = useMemo(() => new Set(clients.map((c) => c.id)), [clients]);

  const persistSettings = (patch: Partial<ViewerSettings>) => {
    setSettings((s) => {
      const next = { ...s, ...patch };
      saveSettings(next);
      if (patch.cctvFps != null) getCctvSocket().setFps(patch.cctvFps);
      return next;
    });
  };

  const serverHost = getServerHttpUrl().replace(/^https?:\/\//, "");

  return (
    <div className="min-h-screen flex flex-col">
      {/* ============================== TOP BAR ============================== */}
      <header className="sticky top-0 z-30 border-b border-border/60 backdrop-blur-xl"
              style={{ background: "color-mix(in oklab, var(--background) 78%, transparent)" }}>
        <div className="px-5 py-3 flex items-center gap-4">
          {/* Live stats */}
          <div className="flex items-center gap-2">
            <StatChip label="online" value={String(clients.length)} tone="primary" />
            <StatChip label="host" value={serverHost || "—"} mono />
            <ConnectionBadge status={status} />
          </div>


          <div className="flex-1" />

          {/* Mode switch */}
          <SegmentedControl
            value={mode}
            onChange={setMode}
            items={[
              { value: "layout", label: "Layout", icon: <IconLayout /> },
              { value: "grid",   label: "Grid",   icon: <IconGrid /> },
            ]}
          />

          {/* Contextual actions */}
          {mode === "layout" && (
            <div className="flex items-center gap-1">
              <ToolbarButton
                onClick={() => setEditing((v) => !v)}
                active={editing}
                icon={<IconArrange />}
              >
                {editing ? "Done" : "Arrange"}
              </ToolbarButton>
              {editing && (
                <ToolbarButton onClick={clearLayout} icon={<IconReset />}>
                  Reset
                </ToolbarButton>
              )}
            </div>
          )}

          {mode === "grid" && (
            <GridControls
              zoom={settings.gridZoom}
              fps={settings.cctvFps}
              onZoom={(z) => persistSettings({ gridZoom: z })}
              onFps={(f) => persistSettings({ cctvFps: f })}
            />
          )}

          <IconButton onClick={() => setShowSettings(true)} label="Settings">
            <IconGear />
          </IconButton>
        </div>

      </header>

      {/* ============================== BODY ============================== */}
      {mode === "layout" ? (
        <div
          ref={canvasRef}
          className={`flex-1 relative overflow-auto ${editing ? "bg-grid-editing" : "bg-grid"}`}
        >
          {editing && (
            <div className="sticky top-3 mx-auto w-fit z-10 px-3 py-1.5 rounded-full text-[11px]
                            bg-card/80 backdrop-blur border border-primary/40 text-foreground/90
                            shadow-lg flex items-center gap-2">
              <span className="size-1.5 rounded-full bg-primary animate-pulse" />
              Drag tiles to arrange · positions saved automatically
            </div>
          )}
          {clients.length === 0 ? (
            <EmptyState status={status} onOpenSettings={() => setShowSettings(true)} />
          ) : (
            clients.map((c) => (
              <PcCard
                key={c.id}
                client={c}
                pos={layout[c.id] ?? { x: GRID, y: GRID }}
                editing={editing}
                online={onlineIds.has(c.id)}
                onMove={(p) => updatePos(c.id, p)}
                canvasRef={canvasRef}
              />
            ))
          )}
        </div>
      ) : (
        <GridView
          clients={clients}
          zoom={settings.gridZoom}
          fps={settings.cctvFps}
          appFilter={settings.appFilter}
          status={status}
          onOpenSettings={() => setShowSettings(true)}
        />
      )}

      {showSettings && (
        <SettingsModal
          settings={settings}
          onChange={persistSettings}
          onClose={() => setShowSettings(false)}
          baseColor={baseColor}
          onBaseColor={setBaseColor}
        />
      )}
    </div>
  );
}

/* ============================ Chrome ============================ */


function StatChip({ label, value, mono, tone }: {
  label: string; value: string; mono?: boolean; tone?: "primary";
}) {
  return (
    <div className="flex items-center gap-2 h-8 pl-2.5 pr-3 rounded-md border border-border/60 bg-card/50">
      <span className="text-[9.5px] uppercase tracking-[0.14em] text-muted-foreground">{label}</span>
      <span className={`text-xs ${mono ? "font-mono" : "font-semibold"} ${tone === "primary" ? "text-primary" : "text-foreground"}`}>
        {value}
      </span>
    </div>
  );
}

function ConnectionBadge({ status }: { status: Status }) {
  const map = {
    online:     { color: "var(--online)",  label: "Live",       glow: true },
    connecting: { color: "var(--warn)",    label: "Connecting", glow: false },
    offline:    { color: "var(--offline)", label: "Offline",    glow: false },
  }[status];
  return (
    <div className="flex items-center gap-2 h-8 px-3 rounded-md border border-border/60 bg-card/50">
      <span
        className={`size-1.5 rounded-full ${status === "online" ? "animate-pulse-ring" : ""}`}
        style={{ background: map.color, boxShadow: map.glow ? `0 0 8px ${map.color}` : "none" }}
      />
      <span className="text-[11px] font-medium tracking-wide">{map.label}</span>
    </div>
  );
}

function SegmentedControl<T extends string>({
  value, onChange, items,
}: {
  value: T; onChange: (v: T) => void;
  items: { value: T; label: string; icon: React.ReactNode }[];
}) {
  return (
    <div className="relative flex p-0.5 rounded-md bg-card/60 border border-border/60">
      {items.map((it) => {
        const active = it.value === value;
        return (
          <button
            key={it.value}
            onClick={() => onChange(it.value)}
            className={`relative h-7 px-3 rounded-[5px] text-xs font-medium flex items-center gap-1.5 transition
              ${active ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}
          >
            <span className="size-3.5">{it.icon}</span>
            {it.label}
          </button>
        );
      })}
    </div>
  );
}

function ToolbarButton({ children, onClick, active, icon }: {
  children: React.ReactNode; onClick: () => void; active?: boolean; icon?: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`h-8 px-3 rounded-md text-xs font-medium flex items-center gap-1.5 border transition
        ${active
          ? "bg-primary text-primary-foreground border-primary/70 shadow-[0_0_0_3px_color-mix(in_oklab,var(--primary)_20%,transparent)]"
          : "border-border/60 bg-card/50 text-foreground/80 hover:text-foreground hover:border-border"}`}
    >
      {icon && <span className="size-3.5">{icon}</span>}
      {children}
    </button>
  );
}

function IconButton({ children, onClick, label }: {
  children: React.ReactNode; onClick: () => void; label: string;
}) {
  return (
    <button
      onClick={onClick}
      aria-label={label}
      className="size-8 grid place-items-center rounded-md border border-border/60 bg-card/50 text-muted-foreground hover:text-foreground hover:border-border transition"
    >
      <span className="size-4">{children}</span>
    </button>
  );
}

/* ============================ Empty state ============================ */

function EmptyState({ status, onOpenSettings }: { status: Status; onOpenSettings: () => void }) {
  const copy = status === "online" ? {
    title: "Waiting for agents",
    body: "Install the agent on a lab PC and it will appear here within seconds.",
  } : status === "connecting" ? {
    title: "Connecting to server…",
    body: "Establishing WebSocket link to the monitor service.",
  } : {
    title: "Server unreachable",
    body: "The monitor service isn't responding. Verify the URL and try again.",
  };
  return (
    <div className="absolute inset-0 flex items-center justify-center p-6">
      <div className="max-w-sm text-center">
        <div
          className="mx-auto mb-5 size-16 rounded-2xl grid place-items-center border border-border bg-card"
        >
          <div
            className={`size-3 rounded-full ${status === "online" ? "animate-pulse-ring" : ""}`}
            style={{
              background: status === "online" ? "var(--online)" : status === "connecting" ? "var(--warn)" : "var(--offline)",
              boxShadow: status === "online" ? "0 0 12px var(--online)" : "none",
            }}
          />
        </div>
        <h2 className="text-base font-semibold tracking-tight">{copy.title}</h2>
        <p className="text-sm text-muted-foreground mt-1.5">{copy.body}</p>
        {status === "offline" && (
          <button
            onClick={onOpenSettings}
            className="mt-4 px-3 py-2 text-xs rounded-md bg-primary text-primary-foreground font-medium hover:opacity-90"
          >
            Configure server URL
          </button>
        )}
      </div>
    </div>
  );
}

/* ============================ Grid view ============================ */

function GridControls({
  zoom, fps, onZoom, onFps,
}: {
  zoom: number; fps: number;
  onZoom: (z: number) => void; onFps: (f: number) => void;
}) {
  return (
    <div className="flex items-center gap-1 h-8 pl-2 pr-1 rounded-md border border-border/60 bg-card/50">
      <span className="text-[9.5px] uppercase tracking-[0.14em] text-muted-foreground">fps</span>
      <select
        value={fps}
        onChange={(e) => onFps(Number(e.target.value))}
        className="h-6 bg-transparent text-xs font-mono focus:outline-none pr-1"
      >
        {[1, 2, 3, 4, 6, 8].map((f) => <option key={f} value={f} className="bg-card">{f}</option>)}
      </select>
      <span className="mx-1 h-4 w-px bg-border/70" />
      <button
        onClick={() => onZoom(Math.max(0.4, +(zoom - 0.15).toFixed(2)))}
        className="size-6 grid place-items-center rounded text-muted-foreground hover:text-foreground hover:bg-accent"
        aria-label="Zoom out"
      >−</button>
      <span className="text-[10px] font-mono text-muted-foreground tabular-nums w-9 text-center">
        {Math.round(zoom * 100)}%
      </span>
      <button
        onClick={() => onZoom(Math.min(3, +(zoom + 0.15).toFixed(2)))}
        className="size-6 grid place-items-center rounded text-muted-foreground hover:text-foreground hover:bg-accent"
        aria-label="Zoom in"
      >+</button>
      <button
        onClick={() => onZoom(1)}
        className="h-6 px-1.5 text-[10px] rounded text-muted-foreground hover:text-foreground hover:bg-accent"
      >fit</button>
    </div>
  );
}

function GridView({
  clients, zoom, fps, appFilter, status, onOpenSettings,
}: {
  clients: ClientInfo[]; zoom: number; fps: number; appFilter: string[];
  status: Status; onOpenSettings: () => void;
}) {
  
  const compiled = useMemo(() => compileFilter(appFilter), [appFilter]);

  useEffect(() => { getCctvSocket().setFps(fps); }, [fps]);

  if (!clients.length) {
    return (
      <div className="flex-1 relative">
        <EmptyState status={status} onOpenSettings={onOpenSettings} />
      </div>
    );
  }

  const cols = Math.max(1, Math.min(8, Math.round(4 / zoom)));
  return (
    <div className="flex-1 overflow-auto p-4">
      <div
        className="grid gap-3"
        style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}
      >
        {clients.map((c) => (
          <GridTile key={c.id} client={c} fps={fps} filter={compiled} />
        ))}
      </div>
    </div>
  );
}

function pickDisplayApp(apps: AppsSnapshot | null, filter: RegExp[]) {
  if (!apps) return null;
  if (apps.foreground && !isFilteredProc(apps.foreground.proc, filter)) return apps.foreground;
  return apps.apps.find((a) => !isFilteredProc(a.proc, filter)) ?? null;
}

function GridTile({
  client, fps, filter,
}: {
  client: ClientInfo; fps: number; filter: RegExp[];
}) {
  const navigate = useNavigate();
  const [src, setSrc] = useState<string | null>(null);
  const [lastAt, setLastAt] = useState<number>(0);
  const [apps, setApps] = useState<AppsSnapshot | null>(null);
  const [, tick] = useState(0);
  const label = client.label || client.hostname || client.id;

  useEffect(() => {
    const sock = getCctvSocket();
    sock.subscribe(
      client.id,
      (url) => { setSrc(url); setLastAt(Date.now()); },
      (a) => setApps(a),
    );
    return () => { sock.unsubscribe(client.id); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [client.id]);

  useEffect(() => { getCctvSocket().setFps(fps); }, [fps]);

  // Repaint every second so the "stale" heuristic updates without a new frame.
  useEffect(() => {
    const t = setInterval(() => tick((n) => n + 1), 1000);
    return () => clearInterval(t);
  }, []);

  const stale = lastAt > 0 && Date.now() - lastAt > 4000;
  const displayApp = pickDisplayApp(apps, filter);
  const appName = displayApp ? prettyProcName(displayApp.proc) : null;
  const appTitle = displayApp?.title || "";

  return (
    <button
      type="button"
      onClick={() => navigate({ to: "/view/$clientId", params: { clientId: client.id } })}
      className="group relative aspect-video rounded-lg overflow-hidden text-left
                 border border-border/60 bg-[oklch(0.08_0.005_220)]
                 hover:border-primary/70 focus:outline-none focus:ring-2 focus:ring-primary/50
                 transition-all"
      style={{ boxShadow: "var(--shadow-tile)" }}
    >
      {/* Video frame */}
      {src ? (
        <img src={src} alt={label} className="absolute inset-0 w-full h-full object-contain" />
      ) : (
        <div className="absolute inset-0 grid place-items-center">
          <div className="flex flex-col items-center gap-2 text-muted-foreground">
            <div className="size-6 rounded-full border-2 border-current border-t-transparent animate-spin opacity-60" />
            <span className="text-[10px] font-mono uppercase tracking-wider opacity-70">acquiring signal</span>
          </div>
        </div>
      )}

      {/* Faint scanline sweep — decoration only */}
      {src && !stale && (
        <div className="pointer-events-none absolute inset-0 overflow-hidden opacity-[0.06] mix-blend-screen">
          <div className="absolute inset-x-0 h-8 bg-gradient-to-b from-transparent via-primary to-transparent animate-scan" />
        </div>
      )}

      {/* Corner brackets */}
      <CornerBrackets />

      {/* Top overlay */}
      <div className="absolute inset-x-0 top-0 px-2.5 py-2 flex items-center gap-2
                      bg-gradient-to-b from-black/75 via-black/40 to-transparent">
        <span
          className={`size-1.5 rounded-full shrink-0 ${!stale ? "animate-pulse-ring" : ""}`}
          style={{
            background: stale ? "var(--warn)" : "var(--online)",
            boxShadow: stale ? "none" : "0 0 6px var(--online)",
          }}
        />
        <span className="text-[11.5px] font-semibold text-white truncate">{label}</span>
        <span className="ml-auto text-[10px] font-mono text-white/60 truncate">{client.ip}</span>
      </div>

      {/* Stale ribbon */}
      {stale && (
        <div className="absolute top-9 right-2 px-1.5 py-0.5 rounded text-[9px] font-mono uppercase tracking-wider
                        bg-stripes border border-[color-mix(in_oklab,var(--warn)_45%,transparent)] text-white/90">
          stale
        </div>
      )}

      {/* Bottom overlay: active app */}
      <div className="absolute inset-x-0 bottom-0 px-2.5 py-2 bg-gradient-to-t from-black/85 via-black/55 to-transparent">
        {appName ? (
          <div className="flex items-baseline gap-1.5 min-w-0">
            <span className="text-[11.5px] font-semibold text-primary truncate drop-shadow">{appName}</span>
            {appTitle && (
              <span className="text-[10px] font-mono text-white/60 truncate">· {appTitle}</span>
            )}
          </div>
        ) : (
          <span className="text-[10px] font-mono text-white/40 italic">
            {apps ? "no user apps" : "…"}
          </span>
        )}
      </div>

      {/* Hover CTA */}
      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition
                      bg-[color-mix(in_oklab,var(--primary)_10%,transparent)]
                      grid place-items-center pointer-events-none">
        <span className="px-2.5 py-1 rounded-md text-[11px] font-semibold
                         bg-primary text-primary-foreground shadow-lg">
          Open stream →
        </span>
      </div>
    </button>
  );
}

function CornerBrackets() {
  const base = "absolute size-4 border-white/25";
  return (
    <>
      <span className={`${base} top-1 left-1 border-t border-l`} />
      <span className={`${base} top-1 right-1 border-t border-r`} />
      <span className={`${base} bottom-1 left-1 border-b border-l`} />
      <span className={`${base} bottom-1 right-1 border-b border-r`} />
    </>
  );
}

/* ============================ PC Card (layout mode) ============================ */

function PcCard({
  client, pos, editing, online, onMove, canvasRef,
}: {
  client: ClientInfo;
  pos: Pos;
  editing: boolean;
  online: boolean;
  onMove: (p: Pos) => void;
  canvasRef: React.RefObject<HTMLDivElement | null>;
}) {
  const navigate = useNavigate();
  const [drag, setDrag] = useState<{ dx: number; dy: number; x: number; y: number } | null>(null);
  const label = client.label || client.hostname || client.id;

  const onPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!editing) return;
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    setDrag({ dx: e.clientX - pos.x, dy: e.clientY - pos.y, x: pos.x, y: pos.y });
  };
  const onPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!drag) return;
    const canvas = canvasRef.current;
    const maxX = (canvas?.scrollWidth ?? 2000) - CARD_W - 4;
    const maxY = (canvas?.scrollHeight ?? 2000) - CARD_H - 4;
    const nx = Math.min(maxX, Math.max(0, e.clientX - drag.dx));
    const ny = Math.min(maxY, Math.max(0, e.clientY - drag.dy));
    setDrag({ ...drag, x: nx, y: ny });
  };
  const onPointerUp = () => {
    if (!drag) return;
    onMove({ x: snap(drag.x), y: snap(drag.y) });
    setDrag(null);
  };

  const displayed = drag ?? pos;
  const handleClick = () => { if (!editing && !drag) navigate({ to: "/view/$clientId", params: { clientId: client.id } }); };

  return (
    <div
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={onPointerUp}
      onClick={handleClick}
      className={`absolute select-none group transition-shadow
        ${editing ? "cursor-grab active:cursor-grabbing" : "cursor-pointer"}
        ${drag ? "z-10" : ""}`}
      style={{
        left: displayed.x, top: displayed.y, width: CARD_W, height: CARD_H,
        transition: drag ? "none" : "left 140ms cubic-bezier(.2,.8,.2,1), top 140ms cubic-bezier(.2,.8,.2,1)",
      }}
    >
      <div
        className={`relative w-full h-full rounded-lg p-3 flex flex-col justify-between overflow-hidden
                    border transition
                    ${editing ? "border-primary/50" : "border-border group-hover:border-primary/60"}`}
        style={{
          background: "#0a0a0a",
          boxShadow: drag
            ? "0 20px 40px -18px rgba(0,0,0,0.9), 0 0 0 1px color-mix(in oklab, var(--primary) 40%, transparent)"
            : "var(--shadow-tile)",
        }}
      >
        {/* Left status stripe */}
        <span
          className="absolute left-0 top-2 bottom-2 w-[3px] rounded-r"
          style={{
            background: online ? "var(--online)" : "var(--offline)",
            boxShadow: online ? "0 0 10px var(--online)" : "none",
          }}
        />

        <div className="flex items-start gap-2 min-w-0 pl-1.5">
          <div className="min-w-0 flex-1">
            <div className="font-semibold text-sm truncate leading-tight tracking-tight">{label}</div>
            <div className="font-mono text-[10.5px] text-muted-foreground truncate mt-0.5">
              {client.hostname}
            </div>
          </div>
          <span
            className={`text-[9px] font-mono uppercase px-1.5 py-0.5 rounded tracking-wider
              ${online
                ? "text-primary bg-[color-mix(in_oklab,var(--primary)_15%,transparent)]"
                : "text-muted-foreground bg-muted/40"}`}
          >
            {online ? "live" : "off"}
          </span>
        </div>

        <div className="flex items-center justify-between text-[10px] font-mono text-muted-foreground/80 pl-1.5">
          <span className="truncate">{client.ip}</span>
          {!editing && (
            <span className="opacity-0 group-hover:opacity-100 transition-opacity text-primary font-semibold">
              open →
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

/* ============================ Settings modal ============================ */

function SettingsModal({
  settings, onChange, onClose, baseColor, onBaseColor,
}: {
  settings: ViewerSettings;
  onChange: (patch: Partial<ViewerSettings>) => void;
  onClose: () => void;
  baseColor: string;
  onBaseColor: (hex: string) => void;
}) {
  const [url, setUrl] = useState(getServerHttpUrl());
  const [local, setLocal] = useState(settings);

  const commit = () => {
    setServerUrl(url);
    onChange(local);
    window.location.reload();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: "rgba(0,0,0,0.7)", backdropFilter: "blur(6px)" }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg rounded-xl border border-border shadow-2xl overflow-hidden bg-card"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-6 py-4 border-b border-border flex items-center gap-3">
          <div className="size-8 rounded-md grid place-items-center bg-primary">
            <span className="size-4 text-primary-foreground"><IconGear /></span>
          </div>
          <div>
            <div className="text-sm font-semibold">Settings</div>
            <div className="text-[11px] text-muted-foreground">Base color, server connection, streaming quality</div>
          </div>
        </div>

        <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
          <Section title="Base color">
            <div className="flex flex-wrap items-center gap-2">
              {BASE_COLOR_PRESETS.map((p) => {
                const active = p.value.toLowerCase() === baseColor.toLowerCase();
                return (
                  <button
                    key={p.value}
                    type="button"
                    onClick={() => onBaseColor(p.value)}
                    title={p.name}
                    className={`size-7 rounded-full border transition ${active ? "ring-2 ring-offset-2 ring-offset-card ring-white" : "border-border hover:scale-110"}`}
                    style={{ background: p.value }}
                  />
                );
              })}
              <label className="ml-1 inline-flex items-center gap-2 h-7 px-2 rounded-md border border-border cursor-pointer hover:border-white/40">
                <input
                  type="color"
                  value={baseColor}
                  onChange={(e) => onBaseColor(e.target.value)}
                  className="size-4 bg-transparent border-0 p-0 cursor-pointer"
                />
                <span className="text-[10px] font-mono uppercase text-muted-foreground">custom</span>
              </label>
            </div>
            <Hint>Applied instantly. Drives accents, status dots, and highlights across the app.</Hint>
          </Section>

          <Section title="Server">

            <input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="http://192.168.1.10:8080"
              className="w-full h-10 px-3 rounded-md bg-background border border-border font-mono text-sm focus:outline-none focus:border-primary"
            />
            <Hint>Leave default when opening from the server PC. Set only when viewing from another LAN machine.</Hint>
          </Section>

          <Section title="Detail stream">
            <div className="grid grid-cols-2 gap-3">
              <NumField label="fps" min={5} max={60} value={local.streamFps}
                onChange={(v) => setLocal({ ...local, streamFps: v })} />
              <NumField label="bitrate (kbps)" min={200} max={20000} step={100} value={local.streamBitrateKbps}
                onChange={(v) => setLocal({ ...local, streamBitrateKbps: v })} />
            </div>
          </Section>

          <Section title="Grid snapshots">
            <NumField label="snapshot fps" min={1} max={15} value={local.cctvFps}
              onChange={(v) => setLocal({ ...local, cctvFps: v })} />
            <Hint>Lower fps = less bandwidth and CPU. 2 fps is usually plenty for exam monitoring.</Hint>
          </Section>

          <Section title="System-app filter">
            <textarea
              value={local.appFilter.join("\n")}
              onChange={(e) => setLocal({ ...local, appFilter: e.target.value.split(/\r?\n/) })}
              spellCheck={false}
              rows={6}
              className="w-full px-3 py-2 rounded-md bg-background border border-border font-mono text-[11px] focus:outline-none focus:border-primary resize-y"
              placeholder="one regex per line, matched (case-insensitive) against the process name"
            />
            <Hint>
              One regex per line, matched case-insensitively against the process file
              (e.g. <code className="font-mono">^chrome\.exe$</code>). The agent already drops
              obvious Win10/11 shell processes; add extras here without redeploying.
            </Hint>
          </Section>
        </div>

        <div className="px-6 py-3 border-t border-border/60 flex items-center justify-between bg-card/40">
          <button
            onClick={() => setLocal(DEFAULT_SETTINGS)}
            className="text-xs text-muted-foreground hover:text-foreground"
          >
            reset defaults
          </button>
          <div className="flex gap-2">
            <button onClick={onClose} className="h-9 px-4 text-sm text-muted-foreground hover:text-foreground">
              cancel
            </button>
            <button
              onClick={commit}
              className="h-9 px-4 text-sm font-semibold rounded-md bg-primary text-primary-foreground hover:opacity-90"
            >
              save & reload
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="text-[10.5px] font-semibold uppercase tracking-[0.16em] text-muted-foreground mb-2">{title}</h3>
      <div className="space-y-2">{children}</div>
    </div>
  );
}

function Hint({ children }: { children: React.ReactNode }) {
  return <p className="text-[11px] text-muted-foreground leading-relaxed">{children}</p>;
}

function NumField({
  label, value, onChange, min, max, step = 1,
}: {
  label: string; value: number; onChange: (v: number) => void;
  min: number; max: number; step?: number;
}) {
  return (
    <label className="flex flex-col gap-1">
      <span className="text-[9.5px] uppercase tracking-[0.14em] text-muted-foreground">{label}</span>
      <input
        type="number"
        value={value}
        min={min}
        max={max}
        step={step}
        onChange={(e) => onChange(Math.max(min, Math.min(max, Number(e.target.value) || min)))}
        className="h-9 px-2.5 rounded-md bg-background border border-border font-mono text-sm focus:outline-none focus:border-primary"
      />
    </label>
  );
}

/* ============================ Icons ============================ */

const svg = "w-full h-full";
function IconLayout() {
  return (
    <svg viewBox="0 0 24 24" className={svg} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="3" width="7" height="9" rx="1.5" />
      <rect x="14" y="3" width="7" height="5" rx="1.5" />
      <rect x="14" y="12" width="7" height="9" rx="1.5" />
      <rect x="3" y="16" width="7" height="5" rx="1.5" />
    </svg>
  );
}
function IconGrid() {
  return (
    <svg viewBox="0 0 24 24" className={svg} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="3" width="7" height="7" rx="1.2" />
      <rect x="14" y="3" width="7" height="7" rx="1.2" />
      <rect x="3" y="14" width="7" height="7" rx="1.2" />
      <rect x="14" y="14" width="7" height="7" rx="1.2" />
    </svg>
  );
}
function IconArrange() {
  return (
    <svg viewBox="0 0 24 24" className={svg} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M5 9l-2 3 2 3M19 9l2 3-2 3M9 5l3-2 3 2M9 19l3 2 3-2" />
      <circle cx="12" cy="12" r="2.2" />
    </svg>
  );
}
function IconReset() {
  return (
    <svg viewBox="0 0 24 24" className={svg} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 12a9 9 0 1 0 3-6.7" />
      <path d="M3 4v5h5" />
    </svg>
  );
}
function IconGear() {
  return (
    <svg viewBox="0 0 24 24" className={svg} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z" />
    </svg>
  );
}
