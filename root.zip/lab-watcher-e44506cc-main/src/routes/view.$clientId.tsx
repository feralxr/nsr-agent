import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState, useCallback } from "react";
import JMuxer from "jmuxer";
import { getServerWsUrl, loadSettings } from "@/lib/server-config";

export const Route = createFileRoute("/view/$clientId")({
  component: ViewClient,
  head: ({ params }) => ({
    meta: [
      { title: `${params.clientId} — Live View` },
      { name: "robots", content: "noindex" },
    ],
  }),
});

interface Meta { label?: string; hostname?: string; ip?: string }
type Status = "connecting" | "streaming" | "offline";

function ViewClient() {
  const { clientId } = Route.useParams();
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const shellRef = useRef<HTMLDivElement | null>(null);
  const [meta, setMeta] = useState<Meta>({});
  const [stats, setStats] = useState({ fps: 0, kbps: 0, status: "connecting" as Status });
  const [uptime, setUptime] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [hideChrome, setHideChrome] = useState(false);

  useEffect(() => {
    if (!videoRef.current) return;
    const settings = loadSettings();
    const startedAt = Date.now();

    const muxer = new JMuxer({
      node: videoRef.current,
      mode: "video",
      fps: settings.streamFps,
      flushingTime: 0,
      clearBuffer: true,
      debug: false,
    });

    let ws: WebSocket | null = null;
    let stopped = false;
    let frames = 0;
    let bytes = 0;

    const connect = () => {
      if (stopped) return;
      setStats((s) => ({ ...s, status: "connecting" }));
      ws = new WebSocket(`${getServerWsUrl()}/viewer`);
      ws.binaryType = "arraybuffer";

      ws.onopen = () => {
        ws?.send(JSON.stringify({ type: "list_subscribe" }));
        ws?.send(JSON.stringify({
          type: "subscribe",
          clientId,
          fps: settings.streamFps,
          bitrate: settings.streamBitrateKbps * 1000,
        }));
      };

      ws.onmessage = (ev) => {
        if (typeof ev.data === "string") {
          try {
            const msg = JSON.parse(ev.data);
            if (msg.type === "stream_started") setStats((s) => ({ ...s, status: "streaming" }));
            if (msg.type === "client_offline") setStats((s) => ({ ...s, status: "offline" }));
            if (msg.type === "clients") {
              const me = msg.clients.find((c: { id: string }) => c.id === clientId);
              if (me) setMeta({ label: me.label, hostname: me.hostname, ip: me.ip });
            }
          } catch { /* noop */ }
          return;
        }
        const buf = new Uint8Array(ev.data as ArrayBuffer);
        frames++;
        bytes += buf.byteLength;
        muxer.feed({ video: buf });
      };

      ws.onclose = () => {
        setStats((s) => ({ ...s, status: "offline" }));
        if (!stopped) setTimeout(connect, 2000);
      };
      ws.onerror = () => ws?.close();
    };
    connect();

    const iv = setInterval(() => {
      setStats((s) => ({ ...s, fps: frames, kbps: Math.round((bytes * 8) / 1000) }));
      setUptime(Math.floor((Date.now() - startedAt) / 1000));
      frames = 0;
      bytes = 0;
    }, 1000);

    return () => {
      stopped = true;
      clearInterval(iv);
      ws?.close();
      muxer.destroy();
    };
  }, [clientId]);

  const toggleFullscreen = useCallback(async () => {
    const el = shellRef.current;
    if (!el) return;
    if (!document.fullscreenElement) {
      await el.requestFullscreen().catch(() => {});
    } else {
      await document.exitFullscreen().catch(() => {});
    }
  }, []);

  useEffect(() => {
    const onFs = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", onFs);
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "f" || e.key === "F") toggleFullscreen();
      if (e.key === "h" || e.key === "H") setHideChrome((v) => !v);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("fullscreenchange", onFs);
      window.removeEventListener("keydown", onKey);
    };
  }, [toggleFullscreen]);

  const title = meta.label || meta.hostname || clientId;
  const status = stats.status;

  return (
    <div ref={shellRef} className="min-h-screen flex flex-col bg-background relative overflow-hidden">
      {/* ambient gradient backdrop */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-60"
        style={{
          background:
            "radial-gradient(1200px 600px at 20% -10%, color-mix(in oklab, var(--primary) 12%, transparent), transparent 60%), radial-gradient(900px 500px at 100% 110%, color-mix(in oklab, var(--primary) 8%, transparent), transparent 60%)",
        }}
      />

      {!hideChrome && (
        <header className="relative z-10 border-b border-border/50 bg-card/40 backdrop-blur-xl">
          <div className="px-4 sm:px-6 py-3 flex items-center gap-4">
            <Link
              to="/"
              className="group flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs text-muted-foreground hover:text-foreground hover:bg-accent/60 transition-colors"
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" className="transition-transform group-hover:-translate-x-0.5">
                <path d="M19 12H5M12 19l-7-7 7-7" />
              </svg>
              <span className="hidden sm:inline">dashboard</span>
            </Link>

            <div className="h-6 w-px bg-border/70" />

            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2 min-w-0">
                <StatusDot status={status} />
                <h1 className="text-sm font-semibold text-foreground truncate">{title}</h1>
                <StatusPill status={status} />
              </div>
              <div className="font-mono text-[11px] text-muted-foreground truncate mt-0.5">
                {meta.hostname && meta.hostname !== title ? `${meta.hostname} · ` : ""}
                {meta.ip ?? clientId}
              </div>
            </div>

            <div className="hidden md:flex items-center gap-2">
              <Stat label="fps" value={stats.fps.toString()} accent={status === "streaming"} />
              <Stat label="kbps" value={stats.kbps.toString()} />
              <Stat label="uptime" value={formatUptime(uptime)} />
            </div>

            <div className="flex items-center gap-1 shrink-0">
              <IconButton title="Hide UI (H)" onClick={() => setHideChrome(true)}>
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M17.94 17.94A10.06 10.06 0 0 1 12 20c-7 0-10-8-10-8a17.6 17.6 0 0 1 4.06-5.94M9.9 5.08A9.94 9.94 0 0 1 12 5c7 0 10 8 10 8a17.7 17.7 0 0 1-2.16 3.19M1 1l22 22M14.12 14.12A3 3 0 1 1 9.88 9.88" />
                </svg>
              </IconButton>
              <IconButton title="Fullscreen (F)" onClick={toggleFullscreen}>
                {isFullscreen ? (
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M8 3v3a2 2 0 0 1-2 2H3M21 8h-3a2 2 0 0 1-2-2V3M3 16h3a2 2 0 0 1 2 2v3M16 21v-3a2 2 0 0 1 2-2h3" />
                  </svg>
                ) : (
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M3 8V5a2 2 0 0 1 2-2h3M21 8V5a2 2 0 0 0-2-2h-3M3 16v3a2 2 0 0 0 2 2h3M21 16v3a2 2 0 0 1-2 2h-3" />
                  </svg>
                )}
              </IconButton>
            </div>
          </div>
        </header>
      )}

      {/* video stage */}
      <div className="relative z-10 flex-1 flex items-center justify-center p-2 sm:p-4">
        <div
          className="relative w-full h-full max-w-[1920px] rounded-xl overflow-hidden border border-border/60 bg-black shadow-[0_20px_60px_-15px_rgba(0,0,0,0.7)]"
          style={{
            boxShadow:
              "0 0 0 1px color-mix(in oklab, var(--primary) 15%, transparent), 0 25px 80px -20px rgba(0,0,0,0.8)",
          }}
        >
          {/* corner accents */}
          <CornerAccent className="top-2 left-2" />
          <CornerAccent className="top-2 right-2 rotate-90" />
          <CornerAccent className="bottom-2 left-2 -rotate-90" />
          <CornerAccent className="bottom-2 right-2 rotate-180" />

          <video
            ref={videoRef}
            autoPlay
            muted
            playsInline
            className="w-full h-full object-contain bg-black"
          />

          {status !== "streaming" && (
            <div className="absolute inset-0 grid place-items-center bg-black/70 backdrop-blur-sm">
              <div className="text-center px-6">
                {status === "connecting" ? (
                  <>
                    <div className="mx-auto mb-4 size-10 rounded-full border-2 border-primary/30 border-t-primary animate-spin" />
                    <div className="text-sm font-medium text-foreground">Establishing stream</div>
                    <div className="text-xs text-muted-foreground mt-1 font-mono">negotiating with {clientId}…</div>
                  </>
                ) : (
                  <>
                    <div className="mx-auto mb-4 size-10 rounded-full bg-[var(--offline)]/20 grid place-items-center">
                      <div className="size-3 rounded-full bg-[var(--offline)]" />
                    </div>
                    <div className="text-sm font-medium text-foreground">Client is offline</div>
                    <div className="text-xs text-muted-foreground mt-1">Waiting for the agent to reconnect…</div>
                  </>
                )}
              </div>
            </div>
          )}

          {hideChrome && (
            <button
              onClick={() => setHideChrome(false)}
              className="absolute top-3 right-3 px-2.5 py-1 rounded-md bg-black/60 backdrop-blur border border-white/10 text-[11px] font-mono text-white/80 hover:text-white hover:border-white/30 transition-colors"
            >
              show UI · H
            </button>
          )}
        </div>
      </div>

      {!hideChrome && (
        <footer className="relative z-10 border-t border-border/50 bg-card/40 backdrop-blur px-4 sm:px-6 py-2 flex items-center justify-between text-[11px] font-mono text-muted-foreground">
          <div className="flex items-center gap-4">
            <span>H.264 · MSE</span>
            <span className="hidden sm:inline">client · {clientId}</span>
          </div>
          <div className="flex items-center gap-3">
            <kbd className="px-1.5 py-0.5 rounded border border-border bg-muted/40 text-[10px]">F</kbd>
            <span>fullscreen</span>
            <kbd className="px-1.5 py-0.5 rounded border border-border bg-muted/40 text-[10px] ml-2">H</kbd>
            <span>hide UI</span>
          </div>
        </footer>
      )}
    </div>
  );
}

function StatusDot({ status }: { status: Status }) {
  const color = status === "streaming" ? "var(--online)" : status === "connecting" ? "var(--muted-foreground)" : "var(--offline)";
  return (
    <span className="relative inline-flex shrink-0">
      <span
        className="size-2 rounded-full"
        style={{
          background: color,
          boxShadow: status === "streaming" ? `0 0 10px ${color}` : "none",
        }}
      />
      {status === "streaming" && (
        <span
          className="absolute inset-0 rounded-full animate-ping opacity-60"
          style={{ background: color }}
        />
      )}
    </span>
  );
}

function StatusPill({ status }: { status: Status }) {
  const map = {
    streaming: { label: "LIVE", cls: "text-[var(--online)] border-[var(--online)]/40 bg-[var(--online)]/10" },
    connecting: { label: "CONNECTING", cls: "text-muted-foreground border-border bg-muted/30" },
    offline: { label: "OFFLINE", cls: "text-[var(--offline)] border-[var(--offline)]/40 bg-[var(--offline)]/10" },
  } as const;
  const s = map[status];
  return (
    <span className={`text-[9px] font-semibold tracking-[0.12em] px-1.5 py-0.5 rounded border ${s.cls}`}>
      {s.label}
    </span>
  );
}

function Stat({ label, value, accent = false }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className="px-2.5 py-1 rounded-md bg-muted/40 border border-border/60 min-w-[64px]">
      <div className="text-[9px] uppercase tracking-wider text-muted-foreground leading-none">{label}</div>
      <div className={`font-mono text-xs tabular-nums leading-tight mt-0.5 ${accent ? "text-[var(--online)]" : "text-foreground"}`}>
        {value}
      </div>
    </div>
  );
}

function IconButton({ children, onClick, title }: { children: React.ReactNode; onClick: () => void; title: string }) {
  return (
    <button
      onClick={onClick}
      title={title}
      className="size-8 grid place-items-center rounded-md text-muted-foreground hover:text-foreground hover:bg-accent/60 transition-colors"
    >
      {children}
    </button>
  );
}

function CornerAccent({ className = "" }: { className?: string }) {
  return (
    <div
      aria-hidden
      className={`absolute size-4 pointer-events-none ${className}`}
      style={{
        borderTop: "1.5px solid color-mix(in oklab, var(--primary) 70%, transparent)",
        borderLeft: "1.5px solid color-mix(in oklab, var(--primary) 70%, transparent)",
        borderTopLeftRadius: "6px",
      }}
    />
  );
}

function formatUptime(sec: number): string {
  if (sec < 60) return `${sec}s`;
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  if (m < 60) return `${m}m ${s.toString().padStart(2, "0")}s`;
  const h = Math.floor(m / 60);
  return `${h}h ${(m % 60).toString().padStart(2, "0")}m`;
}
