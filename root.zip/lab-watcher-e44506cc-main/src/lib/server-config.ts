// Resolves the LAN server URL. Defaults to same-origin so opening the viewer
// at http://<server-ip>:8080/ Just Works. Overridable via localStorage for
// dev (open the viewer from a laptop while server runs on another PC).
const KEY = "labmon.serverUrl";
const SETTINGS_KEY = "labmon.settings.v1";

export function getServerHttpUrl(): string {
  if (typeof window === "undefined") return "";
  const stored = window.localStorage.getItem(KEY);
  if (stored) return stored.replace(/\/$/, "");
  return `${window.location.protocol}//${window.location.host}`;
}

export function getServerWsUrl(): string {
  return getServerHttpUrl().replace(/^http/, "ws");
}

export function setServerUrl(url: string) {
  window.localStorage.setItem(KEY, url);
}

// ---- viewer settings (fps, grid) ----

export interface ViewerSettings {
  streamFps: number;       // detail-view H.264 fps
  streamBitrateKbps: number;
  cctvFps: number;         // grid-mode JPEG fps
  gridZoom: number;        // 1.0 == fit, >1 zoom in, <1 zoom out
  appFilter: string[];     // regex patterns (case-insensitive) matched against process name
}

import { DEFAULT_APP_FILTER } from "./app-filter";

export const DEFAULT_SETTINGS: ViewerSettings = {
  streamFps: 30,
  streamBitrateKbps: 3000,
  cctvFps: 2,
  gridZoom: 1,
  appFilter: DEFAULT_APP_FILTER,
};

export function loadSettings(): ViewerSettings {
  if (typeof window === "undefined") return { ...DEFAULT_SETTINGS };
  try {
    const raw = window.localStorage.getItem(SETTINGS_KEY);
    if (!raw) return { ...DEFAULT_SETTINGS };
    return { ...DEFAULT_SETTINGS, ...(JSON.parse(raw) as Partial<ViewerSettings>) };
  } catch { return { ...DEFAULT_SETTINGS }; }
}

export function saveSettings(s: ViewerSettings) {
  window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
}
