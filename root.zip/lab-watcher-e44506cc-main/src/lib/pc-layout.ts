// Positions for PC cards on the dashboard canvas, persisted in localStorage.
// Keyed by clientId so a PC keeps its spot across page reloads and reconnects.

const KEY = "labmon.pcLayout.v1";

export const GRID = 20;             // snap grid size in px
export const CARD_W = 180;
export const CARD_H = 108;

export interface Pos { x: number; y: number }
export type Layout = Record<string, Pos>;

export function loadLayout(): Layout {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Layout) : {};
  } catch { return {}; }
}

export function saveLayout(layout: Layout) {
  window.localStorage.setItem(KEY, JSON.stringify(layout));
}

export function snap(v: number): number {
  return Math.max(0, Math.round(v / GRID) * GRID);
}

/** Find first free grid slot for a new PC (row-major, respecting card size + gap). */
export function nextFreeSlot(taken: Pos[], canvasWidth: number): Pos {
  const cols = Math.max(1, Math.floor((canvasWidth - GRID) / (CARD_W + GRID)));
  const isTaken = (x: number, y: number) =>
    taken.some((p) => Math.abs(p.x - x) < CARD_W && Math.abs(p.y - y) < CARD_H);
  for (let r = 0; r < 200; r++) {
    for (let c = 0; c < cols; c++) {
      const x = snap(GRID + c * (CARD_W + GRID));
      const y = snap(GRID + r * (CARD_H + GRID));
      if (!isTaken(x, y)) return { x, y };
    }
  }
  return { x: GRID, y: GRID };
}
