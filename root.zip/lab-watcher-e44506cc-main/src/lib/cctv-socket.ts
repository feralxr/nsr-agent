// Shared viewer WebSocket for the CCTV grid.
// Multiplexes many snapshot subscriptions over one socket and dispatches
// per-client blob URLs + apps updates to React tiles via callback registries.
//
// Server framing:
//   snapshot   :  text {"type":"snapshot","clientId":"...","size":N}  + binary(N)
//   apps list  :  text {"type":"apps","clientId":"...","apps":[...],"foreground":{...}}
//   offline    :  text {"type":"client_offline","clientId":"..."}

import { getServerWsUrl } from "./server-config";

export interface AppEntry { proc: string; title: string; pid: number; foreground?: boolean }
export interface AppsSnapshot { apps: AppEntry[]; foreground: AppEntry | null }

type FrameHandler = (blobUrl: string) => void;
type AppsHandler = (apps: AppsSnapshot) => void;

class CctvSocket {
  private ws: WebSocket | null = null;
  private frameHandlers = new Map<string, FrameHandler>();
  private appsHandlers = new Map<string, AppsHandler>();
  private lastApps = new Map<string, AppsSnapshot>();
  private fps = 2;
  private pendingClientId: string | null = null;
  private lastUrls = new Map<string, string>();
  private retry: ReturnType<typeof setTimeout> | null = null;
  private stopped = false;
  private onStatusCb: ((s: "connecting" | "online" | "offline") => void) | null = null;

  onStatus(cb: (s: "connecting" | "online" | "offline") => void) { this.onStatusCb = cb; }
  private setStatus(s: "connecting" | "online" | "offline") { this.onStatusCb?.(s); }

  connect() {
    if (this.ws || this.stopped) return;
    this.setStatus("connecting");
    const ws = new WebSocket(`${getServerWsUrl()}/viewer`);
    ws.binaryType = "arraybuffer";
    this.ws = ws;

    ws.onopen = () => {
      this.setStatus("online");
      for (const clientId of this.frameHandlers.keys()) {
        ws.send(JSON.stringify({ type: "subscribe_snapshot", clientId, fps: this.fps }));
      }
    };

    ws.onmessage = (ev) => {
      if (typeof ev.data === "string") {
        try {
          const m = JSON.parse(ev.data);
          if (m.type === "snapshot" && typeof m.clientId === "string") {
            this.pendingClientId = m.clientId;
          } else if (m.type === "apps" && typeof m.clientId === "string") {
            const snap: AppsSnapshot = { apps: m.apps || [], foreground: m.foreground || null };
            this.lastApps.set(m.clientId, snap);
            this.appsHandlers.get(m.clientId)?.(snap);
          }
        } catch { /* ignore */ }
        return;
      }
      const cid = this.pendingClientId;
      this.pendingClientId = null;
      if (!cid) return;
      const handler = this.frameHandlers.get(cid);
      if (!handler) return;
      const blob = new Blob([ev.data as ArrayBuffer], { type: "image/jpeg" });
      const url = URL.createObjectURL(blob);
      const prev = this.lastUrls.get(cid);
      this.lastUrls.set(cid, url);
      handler(url);
      if (prev) setTimeout(() => URL.revokeObjectURL(prev), 100);
    };

    ws.onclose = () => {
      this.ws = null;
      this.setStatus("offline");
      if (!this.stopped) this.retry = setTimeout(() => this.connect(), 1500);
    };
    ws.onerror = () => ws.close();
  }

  subscribe(clientId: string, onFrame: FrameHandler, onApps?: AppsHandler) {
    this.frameHandlers.set(clientId, onFrame);
    if (onApps) {
      this.appsHandlers.set(clientId, onApps);
      const cached = this.lastApps.get(clientId);
      if (cached) onApps(cached);
    }
    this.connect();
    if (this.ws?.readyState === 1) {
      this.ws.send(JSON.stringify({ type: "subscribe_snapshot", clientId, fps: this.fps }));
    }
  }

  unsubscribe(clientId: string) {
    this.frameHandlers.delete(clientId);
    this.appsHandlers.delete(clientId);
    const prev = this.lastUrls.get(clientId);
    if (prev) { URL.revokeObjectURL(prev); this.lastUrls.delete(clientId); }
    if (this.ws?.readyState === 1) {
      this.ws.send(JSON.stringify({ type: "unsubscribe_snapshot", clientId }));
    }
  }

  setFps(fps: number) {
    this.fps = Math.max(1, Math.min(15, fps));
    if (this.ws?.readyState === 1) {
      this.ws.send(JSON.stringify({ type: "set_snapshot_fps", fps: this.fps }));
    }
  }

  destroy() {
    this.stopped = true;
    if (this.retry) clearTimeout(this.retry);
    this.frameHandlers.clear();
    this.appsHandlers.clear();
    for (const u of this.lastUrls.values()) URL.revokeObjectURL(u);
    this.lastUrls.clear();
    this.ws?.close();
    this.ws = null;
  }
}

let singleton: CctvSocket | null = null;
export function getCctvSocket(): CctvSocket {
  if (!singleton) singleton = new CctvSocket();
  return singleton;
}
