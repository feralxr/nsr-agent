// Runtime-configurable base accent color (shadcn-style).
// Persisted in localStorage. Applied by setting the --primary CSS variable
// on :root. Foreground is chosen for contrast against the picked color.

const KEY = "labmon.baseColor";

export const BASE_COLOR_PRESETS: { name: string; value: string }[] = [
  { name: "Green",   value: "#22c55e" },
  { name: "Emerald", value: "#10b981" },
  { name: "Cyan",    value: "#06b6d4" },
  { name: "Blue",    value: "#3b82f6" },
  { name: "Violet",  value: "#8b5cf6" },
  { name: "Pink",    value: "#ec4899" },
  { name: "Red",     value: "#ef4444" },
  { name: "Orange",  value: "#f97316" },
  { name: "Amber",   value: "#f59e0b" },
  { name: "Lime",    value: "#84cc16" },
  { name: "Rose",    value: "#f43f5e" },
  { name: "White",   value: "#ffffff" },
];

export const DEFAULT_BASE_COLOR = "#22c55e";

export function loadBaseColor(): string {
  if (typeof window === "undefined") return DEFAULT_BASE_COLOR;
  return window.localStorage.getItem(KEY) || DEFAULT_BASE_COLOR;
}

export function saveBaseColor(hex: string) {
  window.localStorage.setItem(KEY, hex);
  applyBaseColor(hex);
}

/** Choose black or white text depending on the accent's luminance. */
function pickForeground(hex: string): string {
  const h = hex.replace("#", "");
  if (h.length !== 6) return "#000";
  const r = parseInt(h.slice(0, 2), 16) / 255;
  const g = parseInt(h.slice(2, 4), 16) / 255;
  const b = parseInt(h.slice(4, 6), 16) / 255;
  const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
  return lum > 0.55 ? "#000000" : "#000000"; // vivid colors → dark text reads best
}

export function applyBaseColor(hex: string) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  root.style.setProperty("--primary", hex);
  root.style.setProperty("--online", hex);
  root.style.setProperty("--primary-foreground", pickForeground(hex));
}
