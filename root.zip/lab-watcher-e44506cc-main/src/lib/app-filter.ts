// Viewer-side filter for the "currently open app" tile label.
// Users can add regex patterns to hide extra processes without redeploying
// the agent (the agent already drops the obvious Win10/11 shell baseline).

export interface AppFilterState {
  patterns: string[];  // one regex per entry, case-insensitive, matched against process name
}

// Sensible extras beyond the agent's baseline. Everything here is common
// on Win10/11 exam machines but not a "user app" a teacher would care about.
export const DEFAULT_APP_FILTER: string[] = [
  "^msedgewebview2\\.exe$",
  "^WWAHost\\.exe$",
  "^ShellHost\\.exe$",
  "^SnippingTool\\.exe$",
  "^Video\\.UI\\.exe$",
  "^Time\\.exe$",
  "^HxOutlook\\.exe$",
  "^YourPhone\\.exe$",
  "^CrossDeviceService\\.exe$",
];

export function compileFilter(patterns: string[]): RegExp[] {
  const out: RegExp[] = [];
  for (const p of patterns) {
    const trimmed = p.trim();
    if (!trimmed) continue;
    try { out.push(new RegExp(trimmed, "i")); } catch { /* skip bad regex */ }
  }
  return out;
}

export function isFilteredProc(proc: string, compiled: RegExp[]): boolean {
  return compiled.some((r) => r.test(proc));
}

// Friendly display name from a process filename.
// "chrome.exe" -> "Chrome", "Code.exe" -> "Code", "WINWORD.EXE" -> "Winword"
export function prettyProcName(proc: string): string {
  const base = proc.replace(/\.exe$/i, "");
  if (!base) return proc;
  return base.charAt(0).toUpperCase() + base.slice(1);
}
