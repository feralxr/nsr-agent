fn main() {
    #[cfg(windows)]
    {
        // Embed manifest so the service binary has explicit UAC / DPI settings.
        embed_resource::compile("app.rc", embed_resource::NONE)
            .manifest_required()
            .unwrap();
    }
}
