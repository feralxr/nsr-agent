# Lab Monitor — Client Agent (Windows)

Rust Windows service. Screen captures via Windows Graphics Capture API
(silent — does NOT trigger the loading cursor), encodes to H.264, streams
to the Lab Monitor server over LAN WebSocket. Auto-starts at boot,
reconnects forever, restarts itself if killed (SCM auto-recovery), runs
capture in the active user session via `WTSQueryUserToken` + `CreateProcessAsUser`.

## Prerequisites

- Windows 10 1803+ or Windows 11 (WGC requirement)
- [Rustup](https://rustup.rs) with the MSVC toolchain (`x86_64-pc-windows-msvc`)
- Visual Studio 2022 Build Tools (C++ workload) — required by MSVC linker
- Optional (for MSI installer): `cargo install cargo-wix` and WiX Toolset 3.14

## Configure

Edit `config.template.json`:

```json
{ "server": "192.168.1.10", "port": 8080, "client_id": "auto" }
```

- `server` — the static LAN IP of the Lab Monitor server PC.
- `client_id` — `"auto"` uses the machine hostname (recommended).

## Build

```
cd client
cargo build --release
```

Output: `target\release\lab-agent.exe`.

## Deploy manually (per PC)

Copy two files into `C:\Program Files\LabAgent\`:
- `lab-agent.exe`
- `config.json` (rename from `config.template.json`)

Then from an **elevated** PowerShell:

```
cd "C:\Program Files\LabAgent"
.\lab-agent.exe --install
```

That registers the Windows service `LabAgent`, sets it to auto-start at
boot, configures SCM to restart it after 1s if it exits, and starts it
immediately.

To remove:

```
.\lab-agent.exe --uninstall
```

## Debug in the foreground

```
.\lab-agent.exe --console
```

Runs the worker loop in your current terminal so you can see logs.
Useful before installing as a service.

## Build a signed MSI installer (optional)

```
cargo install cargo-wix
cargo wix init      # first time only
cargo wix
```

Produces `target\wix\LabAgent-<version>-x86_64.msi`. That MSI can be
double-clicked (one UAC prompt) or pushed via Group Policy.

## Kill resistance

- Runs as `LocalSystem` → non-admin users cannot stop it from Task Manager
- SCM auto-recovery: restarts 1s after any crash, indefinitely
- Session supervisor: if the worker process in the user session dies or
  the user logs out and back in, the service re-spawns the worker in the
  new session automatically
- (Optional, not enabled by default) A second `LabAgentWatchdog` service
  can be added for cross-service revival. On self-owned lab infra, SCM
  recovery has been sufficient in testing.

## Notes on the cursor bug you hit before

Your previous build used GDI `BitBlt` which sets the system's "app is
busy" wait cursor whenever it copies from the desktop DC. This client
uses the Windows Graphics Capture API (`windows-capture` crate) which
runs on the DWM compositor and is completely invisible to the user.
