#![allow(dead_code)]

// JPEG snapshot encoder used by the CCTV grid mode.
// BGRA (from WGC) -> RGB -> JPEG at the requested quality.
// Cheap CPU: at 2-4 fps and moderate quality this is <5% CPU even at 1080p.

use anyhow::{anyhow, Result};
use image::{codecs::jpeg::JpegEncoder, ExtendedColorType};

pub fn bgra_to_jpeg(bgra: &[u8], width: u32, height: u32, quality: u8) -> Result<Vec<u8>> {
    let pixels = (width as usize) * (height as usize);
    if bgra.len() < pixels * 4 {
        return Err(anyhow!("short bgra frame: {} < {}", bgra.len(), pixels * 4));
    }
    let mut rgb = vec![0u8; pixels * 3];
    for i in 0..pixels {
        let s = i * 4;
        let d = i * 3;
        rgb[d]     = bgra[s + 2];
        rgb[d + 1] = bgra[s + 1];
        rgb[d + 2] = bgra[s];
    }
    let mut out: Vec<u8> = Vec::with_capacity(pixels / 4);
    JpegEncoder::new_with_quality(&mut out, quality)
        .encode(&rgb, width, height, ExtendedColorType::Rgb8)
        .map_err(|e| anyhow!("jpeg encode: {e:?}"))?;
    Ok(out)
}