// Windows Service registration + SCM dispatcher.
// The service runs as LocalSystem; when the console session becomes active,
// we spawn `lab-agent.exe --worker` inside that user session so the screen
// capture can actually see the user's desktop.

use anyhow::{anyhow, Result};
use std::{ffi::OsString, thread, time::Duration};
use windows_service::{
    define_windows_service,
    service::{
        ServiceAccess, ServiceControl, ServiceControlAccept, ServiceErrorControl, ServiceExitCode,
        ServiceInfo, ServiceStartType, ServiceState, ServiceStatus, ServiceType,
    },
    service_control_handler::{self, ServiceControlHandlerResult},
    service_dispatcher,
    service_manager::{ServiceManager, ServiceManagerAccess},
};

pub const SERVICE_NAME: &str = "LabAgent";
pub const DISPLAY_NAME: &str = "Lab Monitor Agent";
pub const DESCRIPTION: &str = "Lab Monitor screen-monitoring agent. Streams display over LAN when requested by the Lab Monitor server.";

define_windows_service!(ffi_service_main, service_main);

pub fn run_service_dispatcher() -> Result<()> {
    service_dispatcher::start(SERVICE_NAME, ffi_service_main)
        .map_err(|e| anyhow!("service_dispatcher::start: {e}"))
}

fn service_main(_arguments: Vec<OsString>) {
    if let Err(e) = run_service() {
        log::error!("service error: {e:#}");
    }
}

fn run_service() -> Result<()> {
    let (shutdown_tx, shutdown_rx) = std::sync::mpsc::channel::<()>();

    let event_handler = move |control_event| -> ServiceControlHandlerResult {
        match control_event {
            ServiceControl::Interrogate => ServiceControlHandlerResult::NoError,
            ServiceControl::Stop => {
                let _ = shutdown_tx.send(());
                ServiceControlHandlerResult::NoError
            }
            _ => ServiceControlHandlerResult::NotImplemented,
        }
    };

    let status_handle = service_control_handler::register(SERVICE_NAME, event_handler)?;
    let set_state = |state: ServiceState| -> Result<()> {
        status_handle.set_service_status(ServiceStatus {
            service_type: ServiceType::OWN_PROCESS,
            current_state: state,
            controls_accepted: ServiceControlAccept::STOP,
            exit_code: ServiceExitCode::Win32(0),
            checkpoint: 0,
            wait_hint: Duration::from_secs(5),
            process_id: None,
        })?;
        Ok(())
    };
    set_state(ServiceState::Running)?;

    // Session-supervisor loop: keep a worker running in the active console session.
    let worker_thread = thread::spawn(move || {
        let mut current_child: Option<crate::worker::SessionChild> = None;
        loop {
            if shutdown_rx.try_recv().is_ok() { break; }

            let active = crate::worker::active_console_session();
            let need_restart = match &current_child {
                None => active.is_some(),
                Some(child) => {
                    !child.is_alive()
                        || active.map(|s| s != child.session_id).unwrap_or(true)
                }
            };

            if need_restart {
                if let Some(mut c) = current_child.take() { c.kill(); }
                if let Some(sid) = active {
                    match crate::worker::spawn_in_session(sid) {
                        Ok(c)  => current_child = Some(c),
                        Err(e) => log::warn!("spawn_in_session({sid}) failed: {e:#}"),
                    }
                }
            }
            thread::sleep(Duration::from_secs(3));
        }
        if let Some(mut c) = current_child.take() { c.kill(); }
    });

    let _ = worker_thread.join();
    set_state(ServiceState::Stopped)?;
    Ok(())
}

// ---- install / uninstall (admin required) ----

pub fn install() -> Result<()> {
    let manager = ServiceManager::local_computer(None::<&str>, ServiceManagerAccess::CONNECT | ServiceManagerAccess::CREATE_SERVICE)?;
    let exe_path = std::env::current_exe()?;
    let info = ServiceInfo {
        name: SERVICE_NAME.into(),
        display_name: DISPLAY_NAME.into(),
        service_type: ServiceType::OWN_PROCESS,
        start_type: ServiceStartType::AutoStart,
        error_control: ServiceErrorControl::Normal,
        executable_path: exe_path,
        launch_arguments: vec![],
        dependencies: vec![],
        account_name: None,      // LocalSystem
        account_password: None,
    };
    let service = manager.create_service(&info, ServiceAccess::CHANGE_CONFIG | ServiceAccess::START)?;
    service.set_description(DESCRIPTION)?;
    // Configure auto-recovery: restart after 1s, indefinitely.
    // (windows-service crate does not wrap SetServiceObjectSecurity for recovery config,
    // so we shell out to sc.exe — same effect, no extra dep.)
    let _ = std::process::Command::new("sc.exe")
        .args(["failure", SERVICE_NAME, "reset=", "0", "actions=", "restart/1000/restart/1000/restart/1000"])
        .status();
    service.start(&[] as &[&str])?;
    println!("Installed and started service '{SERVICE_NAME}'.");
    Ok(())
}

pub fn uninstall() -> Result<()> {
    let manager = ServiceManager::local_computer(None::<&str>, ServiceManagerAccess::CONNECT)?;
    let service = manager.open_service(SERVICE_NAME, ServiceAccess::STOP | ServiceAccess::DELETE | ServiceAccess::QUERY_STATUS)?;
    let _ = service.stop();
    thread::sleep(Duration::from_secs(1));
    service.delete()?;
    println!("Uninstalled service '{SERVICE_NAME}'.");
    Ok(())
}
