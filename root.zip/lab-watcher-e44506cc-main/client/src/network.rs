// WebSocket client. worker.rs runs the reconnect loop around this.

use anyhow::{anyhow, Result};
use futures_util::{SinkExt, StreamExt};
use tokio::net::TcpStream;
use tokio_tungstenite::{connect_async, tungstenite::Message, MaybeTlsStream, WebSocketStream};
use crate::config::Config;

pub struct AgentSocket {
    ws: WebSocketStream<MaybeTlsStream<TcpStream>>,
}

impl AgentSocket {
    pub async fn connect(cfg: &Config) -> Result<Self> {
        let url = cfg.ws_url();
        let (ws, _) = connect_async(&url).await.map_err(|e| anyhow!("connect {url}: {e}"))?;
        let mut this = Self { ws };
        let hello = serde_json::json!({
            "type": "hello",
            "clientId": cfg.resolved_client_id(),
            "hostname": gethostname::gethostname().to_string_lossy(),
            "label": cfg.resolved_label(),
        });
        this.ws.send(Message::Text(hello.to_string().into())).await?;
        Ok(this)
    }

    /// Await the next control message (text). Returns the "type" field.
    pub async fn recv_control(&mut self) -> Result<String> {
        let v = self.recv_control_json().await?;
        Ok(v.get("type").and_then(|x| x.as_str()).unwrap_or("").to_string())
    }

    /// Await the next control message (text). Returns the full parsed JSON.
    pub async fn recv_control_json(&mut self) -> Result<serde_json::Value> {
        loop {
            match self.ws.next().await {
                Some(Ok(Message::Text(t))) => {
                    let v: serde_json::Value = serde_json::from_str(&t).unwrap_or_default();
                    if v.get("type").and_then(|x| x.as_str()).is_some() {
                        return Ok(v);
                    }
                }
                Some(Ok(Message::Ping(p))) => { let _ = self.ws.send(Message::Pong(p)).await; }
                Some(Ok(Message::Close(_))) | None => return Err(anyhow!("ws closed")),
                Some(Err(e)) => return Err(anyhow!("ws error: {e}")),
                _ => {}
            }
        }
    }

    pub async fn send_binary(&mut self, data: &[u8]) -> Result<()> {
        self.ws.send(Message::Binary(data.to_vec().into())).await?;
        Ok(())
    }

    pub async fn send_pong(&mut self) -> Result<()> {
        self.send_text("{\"type\":\"pong\"}".into()).await
    }

    pub async fn send_text(&mut self, s: String) -> Result<()> {
        self.ws.send(Message::Text(s.into())).await?;
        Ok(())
    }
}
