#![allow(dead_code)]

// Enumerate visible top-level user windows and their owning processes so the
// viewer's CCTV grid can show "what's this student running right now".
//
// Filtering is intentionally split across the pipeline:
//   1. Here (agent): a hard baseline drop-list removes obvious shell/OS chrome
//      that has visible windows on every Win10/11 install and is never useful
//      for exam monitoring (explorer.exe, ShellExperienceHost, dwm, etc).
//   2. Viewer settings: teachers can add custom regex patterns to hide extra
//      processes at display time without pushing new agents.
//
// We collect ALL non-baseline windows plus mark the current foreground so the
// tile can highlight the app the student is actually focused on.

use serde::Serialize;
use windows::core::PWSTR;
use windows::Win32::Foundation::{BOOL, CloseHandle, HANDLE, HWND, LPARAM, MAX_PATH};
use windows::Win32::Graphics::Dwm::{DwmGetWindowAttribute, DWMWA_CLOAKED};
use windows::Win32::System::Threading::{
    OpenProcess, QueryFullProcessImageNameW, PROCESS_NAME_WIN32,
    PROCESS_QUERY_LIMITED_INFORMATION,
};
use windows::Win32::UI::WindowsAndMessaging::{
    EnumWindows, GetForegroundWindow, GetWindow, GetWindowLongW, GetWindowTextLengthW,
    GetWindowTextW, GetWindowThreadProcessId, IsWindowVisible, GWL_EXSTYLE, GW_OWNER,
    WS_EX_TOOLWINDOW,
};

#[derive(Serialize, Clone, Debug)]
pub struct AppInfo {
    #[serde(rename = "proc")]
    pub process: String,
    pub title: String,
    pub pid: u32,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub foreground: Option<bool>,
}

// Hard baseline: Windows shell / IME / notification chrome that always has
// visible top-level windows and is never a "user app".
const SYSTEM_BASELINE: &[&str] = &[
    "explorer.exe",
    "dwm.exe",
    "sihost.exe",
    "ctfmon.exe",
    "RuntimeBroker.exe",
    "ApplicationFrameHost.exe", // just the frame; real UWP process is separate
    "ShellExperienceHost.exe",
    "StartMenuExperienceHost.exe",
    "SearchHost.exe",
    "SearchApp.exe",
    "SearchUI.exe",
    "TextInputHost.exe",
    "LockApp.exe",
    "SystemSettings.exe",
    "SecurityHealthSystray.exe",
    "SecurityHealthService.exe",
    "WidgetService.exe",
    "Widgets.exe",
    "PhoneExperienceHost.exe",
    "GameBar.exe",
    "GameBarPresenceWriter.exe",
    "smartscreen.exe",
    "UserOOBEBroker.exe",
    "NVIDIA Overlay.exe",
    "NVIDIA Share.exe",
    "Taskmgr.exe", // usually opened by system, borderline — keep if you want it
];

fn is_system_baseline(name: &str) -> bool {
    SYSTEM_BASELINE.iter().any(|s| s.eq_ignore_ascii_case(name))
}

fn window_title(hwnd: HWND) -> String {
    unsafe {
        let len = GetWindowTextLengthW(hwnd);
        if len <= 0 { return String::new(); }
        let mut buf = vec![0u16; (len + 1) as usize];
        let n = GetWindowTextW(hwnd, &mut buf);
        String::from_utf16_lossy(&buf[..n as usize])
    }
}

fn is_cloaked(hwnd: HWND) -> bool {
    unsafe {
        let mut cloaked: u32 = 0;
        let ok = DwmGetWindowAttribute(
            hwnd,
            DWMWA_CLOAKED,
            &mut cloaked as *mut _ as *mut _,
            std::mem::size_of::<u32>() as u32,
        );
        ok.is_ok() && cloaked != 0
    }
}

fn process_name_from_pid(pid: u32) -> Option<String> {
    unsafe {
        let handle: HANDLE = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, false, pid).ok()?;
        let mut buf = vec![0u16; MAX_PATH as usize];
        let mut size = buf.len() as u32;
        let ok = QueryFullProcessImageNameW(
            handle,
            PROCESS_NAME_WIN32,
            PWSTR(buf.as_mut_ptr()),
            &mut size,
        );
        let _ = CloseHandle(handle);
        if ok.is_err() { return None; }
        let path = String::from_utf16_lossy(&buf[..size as usize]);
        let file = path.rsplit('\\').next().unwrap_or(&path).to_string();
        Some(file)
    }
}

struct EnumState {
    apps: Vec<AppInfo>,
    foreground_hwnd: HWND,
}

unsafe extern "system" fn enum_proc(hwnd: HWND, lparam: LPARAM) -> BOOL {
    let state = &mut *(lparam.0 as *mut EnumState);

    // Filter obvious non-app windows.
    if !IsWindowVisible(hwnd).as_bool() { return true.into(); }
    
    // SAFE FIX: Handles the Result<HWND, Error> safely to prevent compiler error and crashes
    if GetWindow(hwnd, GW_OWNER).is_ok_and(|w| w.0 as usize != 0) { return true.into(); }
    
    // Skip tool windows (floating palettes, tray helpers).
    let ex = GetWindowLongW(hwnd, GWL_EXSTYLE) as u32;
    if ex & WS_EX_TOOLWINDOW.0 != 0 { return true.into(); }
    if is_cloaked(hwnd) { return true.into(); }

    let title = window_title(hwnd);
    if title.trim().is_empty() { return true.into(); }

    let mut pid: u32 = 0;
    GetWindowThreadProcessId(hwnd, Some(&mut pid));
    if pid == 0 { return true.into(); }

    let process = match process_name_from_pid(pid) {
        Some(p) => p,
        None => return true.into(),
    };
    if is_system_baseline(&process) { return true.into(); }

    let foreground = if hwnd == state.foreground_hwnd { Some(true) } else { None };
    state.apps.push(AppInfo { process, title, pid, foreground });
    true.into()
}

pub fn enumerate_visible_apps() -> Vec<AppInfo> {
    let mut state = EnumState {
        apps: Vec::new(),
        foreground_hwnd: unsafe { GetForegroundWindow() },
    };
    let lparam = LPARAM(&mut state as *mut _ as isize);
    let _ = unsafe { EnumWindows(Some(enum_proc), lparam) };
    // De-duplicate by process — keep the foreground entry if any, then first
    // seen per process. Preserves ordering for stable UI.
    let mut seen: std::collections::HashSet<String> = std::collections::HashSet::new();
    let mut out: Vec<AppInfo> = Vec::new();
    for a in state.apps.into_iter() {
        if seen.insert(a.process.to_ascii_lowercase()) {
            out.push(a);
        } else if a.foreground.unwrap_or(false) {
            // Upgrade the existing entry's foreground flag.
            if let Some(existing) = out.iter_mut().find(|e| e.process.eq_ignore_ascii_case(&a.process)) {
                existing.foreground = Some(true);
                existing.title = a.title;
            }
        }
    }
    out
}