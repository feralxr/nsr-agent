use serde::{Deserialize, Serialize};
use std::path::PathBuf;

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct Config {
    /// Server IP or hostname (LAN). Example: "192.168.1.10"
    pub server: String,
    /// Server port. Default 8080.
    #[serde(default = "default_port")]
    pub port: u16,
    /// Stable identifier for this PC. "auto" -> use hostname.
    /// This is what the server uses to identify the machine internally.
    #[serde(default = "default_client_id")]
    pub client_id: String,
    /// Human-readable name shown in the viewer grid.
    /// If empty/omitted, viewer falls back to client_id.
    /// Set this per-PC to something meaningful ("PC-01", "Row3-Seat5", "Teacher").
    #[serde(default)]
    pub label: String,
}

fn default_port() -> u16 { 8080 }
fn default_client_id() -> String { "auto".into() }

impl Config {
    /// Load config.json next to the executable.
    pub fn load() -> anyhow::Result<Self> {
        let path = Self::path()?;
        let s = std::fs::read_to_string(&path)
            .map_err(|e| anyhow::anyhow!("read {}: {}", path.display(), e))?;
        Ok(serde_json::from_str(&s)?)
    }

    pub fn path() -> anyhow::Result<PathBuf> {
        let mut p = std::env::current_exe()?;
        p.pop();
        p.push("config.json");
        Ok(p)
    }

    pub fn ws_url(&self) -> String {
        format!("ws://{}:{}/agent", self.server, self.port)
    }

    pub fn resolved_client_id(&self) -> String {
        if self.client_id == "auto" || self.client_id.is_empty() {
            gethostname::gethostname().to_string_lossy().into_owned()
        } else {
            self.client_id.clone()
        }
    }

    pub fn resolved_label(&self) -> String {
        if self.label.trim().is_empty() { self.resolved_client_id() } else { self.label.clone() }
    }
}
