// Windows Graphics Capture wrapper. Silent — fixes the loading-cursor bug
// caused by GDI BitBlt.
//
// Stop mechanism: shared AtomicBool checked inside on_frame_arrived. When
// set, we call control.stop() so windows-capture's message pump exits.
// Capturer::drop() sets the flag, so dropping from an async task is safe
// (no blocking join, no deadlock).

use anyhow::Result;
use std::sync::{
    atomic::{AtomicBool, Ordering},
    Arc, Mutex,
};
use windows_capture::{
    capture::{Context, GraphicsCaptureApiHandler},
    frame::Frame,
    graphics_capture_api::InternalCaptureControl,
    monitor::Monitor,
    settings::{
        ColorFormat, CursorCaptureSettings, DirtyRegionSettings, DrawBorderSettings,
        MinimumUpdateIntervalSettings, SecondaryWindowSettings, Settings,
    },
};

type Callback = Arc<Mutex<Box<dyn FnMut(Vec<u8>, u32, u32) + Send>>>;
type Shared = (Callback, Arc<AtomicBool>);

struct Handler {
    cb: Callback,
    stop: Arc<AtomicBool>,
}

impl GraphicsCaptureApiHandler for Handler {
    type Flags = Shared;
    type Error = std::io::Error;

    fn new(ctx: Context<Self::Flags>) -> Result<Self, Self::Error> {
        let (cb, stop) = ctx.flags;
        Ok(Self { cb, stop })
    }

    fn on_frame_arrived(
        &mut self,
        frame: &mut Frame,
        control: InternalCaptureControl,
    ) -> Result<(), Self::Error> {
        if self.stop.load(Ordering::Relaxed) {
            control.stop();
            return Ok(());
        }

        let width = frame.width();
        let height = frame.height();
        let mut buf = frame
            .buffer()
            .map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, format!("{e:?}")))?;
        let raw = buf.as_raw_buffer();
        let stride = raw.len() / height as usize;
        let row_bytes = (width * 4) as usize;
        let mut out = Vec::with_capacity(row_bytes * height as usize);
        for y in 0..height as usize {
            let s = y * stride;
            out.extend_from_slice(&raw[s..s + row_bytes]);
        }
        if let Ok(mut cb) = self.cb.lock() {
            (cb)(out, width, height);
        }
        Ok(())
    }

    fn on_closed(&mut self) -> Result<(), Self::Error> { Ok(()) }
}

pub struct Capturer {
    stop_flag: Arc<AtomicBool>,
    // The WGC thread cleans itself up after we set stop_flag; we don't join.
    _thread: std::thread::JoinHandle<()>,
}

impl Capturer {
    pub fn start<F>(_target_fps: u32, with_cursor: bool, on_frame: F) -> Result<Self>
    where
        F: FnMut(Vec<u8>, u32, u32) + Send + 'static,
    {
        let cb: Callback = Arc::new(Mutex::new(Box::new(on_frame)));
        let stop_flag = Arc::new(AtomicBool::new(false));
        let flags: Shared = (cb, stop_flag.clone());

        let thread = std::thread::spawn(move || {
            let primary = match Monitor::primary() {
                Ok(m) => m,
                Err(e) => {
                    log::error!("primary monitor: {e:?}");
                    return;
                }
            };

            let cursor_setting = if with_cursor {
                CursorCaptureSettings::WithCursor
            } else {
                CursorCaptureSettings::WithoutCursor
            };

            let settings = Settings::new(
                primary,
                cursor_setting,
                DrawBorderSettings::WithoutBorder,
                SecondaryWindowSettings::Default,
                MinimumUpdateIntervalSettings::Default,
                DirtyRegionSettings::Default,
                ColorFormat::Bgra8,
                flags,
            );

            if let Err(e) = Handler::start(settings) {
                log::error!("capture start: {e:?}");
            }
        });

        Ok(Self { stop_flag, _thread: thread })
    }
}

impl Drop for Capturer {
    fn drop(&mut self) {
        // Non-blocking: WGC pump will observe the flag on its next frame
        // (< 1 frame time) and exit cleanly. Nothing joins the thread here.
        self.stop_flag.store(true, Ordering::Relaxed);
    }
}
