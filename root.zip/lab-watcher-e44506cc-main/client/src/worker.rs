// Runs in the interactive user's session.
//
// One WebSocket to the server, multiplexed:
//   - H.264 stream  : started/stopped by "start_stream" / "stop_stream"
//                     binary frames tagged with 0x01
//   - JPEG snapshots: started/stopped by "start_snapshots" / "stop_snapshots"
//                     binary frames tagged with 0x02
//   - Apps list     : polled every 1.5s while any snapshot subscriber is
//                     active; sent as JSON text {type:"apps", ...}
//
// Both media pipelines drive their own independent Capturer so cursor
// visibility can differ (stream = with cursor, snapshots = without to avoid
// the "loading cursor" artifact on the tile).

use anyhow::{anyhow, Result};
use crate::{
    apps, capture::Capturer, config::Config, encoder::H264Encoder,
    network::AgentSocket, snapshot::bgra_to_jpeg,
};
use std::time::Duration;
use tokio::sync::mpsc;

const TAG_H264: u8 = 0x01;
const TAG_JPEG: u8 = 0x02;

enum EncMsg { Frame(Vec<u8>, u32, u32), Reset }
enum SnapMsg { Frame(Vec<u8>, u32, u32) }

pub async fn run() -> Result<()> {
    loop {
        let cfg = match Config::load() {
            Ok(c) => c,
            Err(e) => {
                log::error!("config load failed: {e:#}. Retrying in 10s.");
                tokio::time::sleep(Duration::from_secs(10)).await;
                continue;
            }
        };
        if let Err(e) = run_once(cfg).await {
            log::warn!("session ended: {e:#}. Reconnecting.");
        }
        tokio::time::sleep(Duration::from_secs(2)).await;
    }
}

async fn run_once(cfg: Config) -> Result<()> {
    let mut sock = AgentSocket::connect(&cfg).await?;
    log::info!("connected as {} (label: {})", cfg.resolved_client_id(), cfg.resolved_label());

    // --- H.264 stream pipeline ---
    let (frame_tx, mut frame_rx) = mpsc::channel::<EncMsg>(4);
    let (nal_tx, mut nal_rx) = mpsc::channel::<Vec<u8>>(16);
    let mut _stream_cap: Option<Capturer> = None;

    let enc_handle = tokio::spawn(async move {
        let mut enc: Option<H264Encoder> = None;
        while let Some(msg) = frame_rx.recv().await {
            match msg {
                EncMsg::Reset => {
                    enc = None;
                    log::info!("encoder reset (next frame will be IDR with SPS/PPS)");
                }
                EncMsg::Frame(frame, w, h) => {
                    let e = enc.get_or_insert_with(|| {
                        H264Encoder::new(w, h, 60, 8_000_000).expect("encoder init")
                    });
                    match e.encode_bgra(&frame) {
                        Ok(nals) => { let _ = nal_tx.send(nals).await; }
                        Err(err) => log::warn!("encode error: {err:#}"),
                    }
                }
            }
        }
    });

    // --- JPEG snapshot pipeline ---
    let (snap_frame_tx, mut snap_frame_rx) = mpsc::channel::<SnapMsg>(2);
    let (jpg_tx, mut jpg_rx) = mpsc::channel::<Vec<u8>>(4);
    let mut _snap_cap: Option<Capturer> = None;
    let mut snap_fps: u32 = 0;

    let snap_handle = tokio::spawn(async move {
        while let Some(SnapMsg::Frame(bgra, w, h)) = snap_frame_rx.recv().await {
            match bgra_to_jpeg(&bgra, w, h, 55) {
                Ok(jpg) => { let _ = jpg_tx.send(jpg).await; }
                Err(err) => log::warn!("jpeg error: {err:#}"),
            }
        }
    });

    // Apps poll ticker (only meaningful when snapshots are active, but cheap
    // enough to always run — a few HWND enumerations per second).
    let mut apps_tick = tokio::time::interval(Duration::from_millis(1500));
    apps_tick.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Delay);

    loop {
        tokio::select! {
            msg = sock.recv_control_json() => {
                let v = msg?;
                let t = v.get("type").and_then(|x| x.as_str()).unwrap_or("");
                match t {
                    "start_stream" => {
                        _stream_cap = None;
                        let _ = frame_tx.send(EncMsg::Reset).await;
                        let tx = frame_tx.clone();
                        _stream_cap = Some(Capturer::start(60, true, move |bgra, w, h| {
                            let _ = tx.try_send(EncMsg::Frame(bgra, w, h));
                        }).map_err(|e| anyhow!("capturer start: {e:#}"))?);
                        log::info!("stream started");
                    }
                    "stop_stream" => {
                        _stream_cap = None;
                        log::info!("stream stopped");
                    }
                    "start_snapshots" => {
                        let fps = v.get("fps").and_then(|x| x.as_u64()).unwrap_or(2) as u32;
                        // Restart if fps changed or not running.
                        if _snap_cap.is_none() || fps != snap_fps {
                            _snap_cap = None;
                            snap_fps = fps.max(1).min(15);
                            let tx = snap_frame_tx.clone();
                            let target = snap_fps;
                            // Throttle to snap_fps: WGC gives us ~60fps; only push
                            // one frame per interval to the JPEG encoder.
                            let interval_ms = (1000 / target).max(50) as u128;
                            let last = std::sync::Arc::new(std::sync::Mutex::new(
                                std::time::Instant::now() - Duration::from_secs(1)
                            ));
                            _snap_cap = Some(Capturer::start(target, false, move |bgra, w, h| {
                                let mut l = last.lock().unwrap();
                                if l.elapsed().as_millis() < interval_ms { return; }
                                *l = std::time::Instant::now();
                                let _ = tx.try_send(SnapMsg::Frame(bgra, w, h));
                            }).map_err(|e| anyhow!("snap capturer start: {e:#}"))?);
                            log::info!("snapshots started @ {snap_fps} fps");
                        }
                    }
                    "stop_snapshots" => {
                        _snap_cap = None;
                        snap_fps = 0;
                        log::info!("snapshots stopped");
                    }
                    "ping" => { sock.send_pong().await?; }
                    _ => {}
                }
            }
            nal = nal_rx.recv() => {
                let Some(nal) = nal else { break; };
                let mut buf = Vec::with_capacity(nal.len() + 1);
                buf.push(TAG_H264);
                buf.extend_from_slice(&nal);
                sock.send_binary(&buf).await?;
            }
            jpg = jpg_rx.recv() => {
                let Some(jpg) = jpg else { break; };
                let mut buf = Vec::with_capacity(jpg.len() + 1);
                buf.push(TAG_JPEG);
                buf.extend_from_slice(&jpg);
                sock.send_binary(&buf).await?;
            }
            _ = apps_tick.tick() => {
                // Only send when snapshots are on — no need to spam the wire
                // otherwise; the viewer only reads apps in CCTV mode.
                if _snap_cap.is_some() {
                    let list = apps::enumerate_visible_apps();
                    let fg = list.iter().find(|a| a.foreground.unwrap_or(false)).cloned();
                    let payload = serde_json::json!({
                        "type": "apps",
                        "apps": list,
                        "foreground": fg,
                    });
                    sock.send_text(payload.to_string()).await?;
                }
            }
        }
    }

    drop(frame_tx);
    drop(snap_frame_tx);
    let _ = enc_handle.await;
    let _ = snap_handle.await;
    Ok(())
}

// ============ session-spawn helpers (used by service.rs) ============

#[cfg(windows)]
pub struct SessionChild {
    pub session_id: u32,
    process_handle: windows::Win32::Foundation::HANDLE,
}

#[cfg(windows)]
impl SessionChild {
    pub fn is_alive(&self) -> bool {
        use windows::Win32::Foundation::STILL_ACTIVE;
        use windows::Win32::System::Threading::GetExitCodeProcess;
        let mut code = 0u32;
        unsafe {
            if GetExitCodeProcess(self.process_handle, &mut code).is_err() { return false; }
        }
        code == STILL_ACTIVE.0 as u32
    }
    pub fn kill(&mut self) {
        use windows::Win32::System::Threading::TerminateProcess;
        unsafe { let _ = TerminateProcess(self.process_handle, 0); }
        unsafe { let _ = windows::Win32::Foundation::CloseHandle(self.process_handle); }
    }
}

#[cfg(windows)]
pub fn active_console_session() -> Option<u32> {
    use windows::Win32::System::RemoteDesktop::WTSGetActiveConsoleSessionId;
    let sid = unsafe { WTSGetActiveConsoleSessionId() };
    if sid == 0xFFFF_FFFF { None } else { Some(sid) }
}

#[cfg(windows)]
pub fn spawn_in_session(session_id: u32) -> Result<SessionChild> {
    use std::os::windows::ffi::OsStrExt;
    use windows::core::PWSTR;
    use windows::Win32::Foundation::{CloseHandle, HANDLE};
    use windows::Win32::System::RemoteDesktop::WTSQueryUserToken;
    use windows::Win32::System::Threading::{
        CreateProcessAsUserW, CREATE_UNICODE_ENVIRONMENT, DETACHED_PROCESS,
        PROCESS_INFORMATION, STARTUPINFOW,
    };

    let exe = std::env::current_exe()?;
    let cmdline: Vec<u16> = std::ffi::OsString::from(format!("\"{}\" --worker", exe.display()))
        .encode_wide().chain(std::iter::once(0)).collect();

    unsafe {
        let mut user_token: HANDLE = HANDLE::default();
        WTSQueryUserToken(session_id, &mut user_token)
            .map_err(|e| anyhow!("WTSQueryUserToken: {e:?}"))?;

        let mut si = STARTUPINFOW::default();
        si.cb = std::mem::size_of::<STARTUPINFOW>() as u32;
        let mut pi = PROCESS_INFORMATION::default();

        let mut cmd = cmdline.clone();
        let ok = CreateProcessAsUserW(
            user_token,
            None,
            PWSTR(cmd.as_mut_ptr()),
            None, None, false,
            CREATE_UNICODE_ENVIRONMENT | DETACHED_PROCESS,
            None, None, &si, &mut pi,
        );
        let _ = CloseHandle(user_token);
        ok.map_err(|e| anyhow!("CreateProcessAsUserW: {e:?}"))?;
        let _ = CloseHandle(pi.hThread);
        Ok(SessionChild { session_id, process_handle: pi.hProcess })
    }
}
