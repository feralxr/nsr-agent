// Software H.264 encoder via openh264. Good enough for LAN.
// For hardware NVENC/QuickSync you'd swap this module for a Media Foundation
// encoder — the rest of the pipeline is unchanged.

use anyhow::{anyhow, Result};
use openh264::encoder::{Encoder, EncoderConfig};
use openh264::formats::{RgbSliceU8, YUVBuffer};

pub struct H264Encoder {
    encoder: Encoder,
    width: u32,
    height: u32,
    rgb_buf: Vec<u8>,
}

impl H264Encoder {
    pub fn new(width: u32, height: u32, fps: u32, bitrate_bps: u32) -> Result<Self> {
        let cfg = EncoderConfig::new()
            .set_bitrate_bps(bitrate_bps)
            .max_frame_rate(fps as f32)
            .rate_control_mode(openh264::encoder::RateControlMode::Bitrate);
        let encoder = Encoder::with_api_config(openh264::OpenH264API::from_source(), cfg)
            .map_err(|e| anyhow!("openh264 init: {e:?}"))?;
        Ok(Self {
            encoder,
            width,
            height,
            rgb_buf: vec![0u8; (width * height * 3) as usize],
        })
    }

    /// Encode a full BGRA frame; returns concatenated NAL units (Annex-B).
    pub fn encode_bgra(&mut self, bgra: &[u8]) -> Result<Vec<u8>> {
        let pixels = (self.width * self.height) as usize;
        if bgra.len() < pixels * 4 {
            return Err(anyhow!("short frame: {} < {}", bgra.len(), pixels * 4));
        }
        // BGRA -> RGB
        for i in 0..pixels {
            let s = i * 4;
            let d = i * 3;
            self.rgb_buf[d]     = bgra[s + 2];
            self.rgb_buf[d + 1] = bgra[s + 1];
            self.rgb_buf[d + 2] = bgra[s];
        }
        let rgb = RgbSliceU8::new(&self.rgb_buf, (self.width as usize, self.height as usize));
        let yuv = YUVBuffer::from_rgb_source(rgb);
        let bit = self.encoder.encode(&yuv).map_err(|e| anyhow!("encode: {e:?}"))?;
        Ok(bit.to_vec())
    }
}
