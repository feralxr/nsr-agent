// Entry point. Dispatches on CLI args:
//   lab-agent.exe                 -> run as Windows service (called by SCM)
//   lab-agent.exe --worker        -> run capture+encode+stream loop (user session)
//   lab-agent.exe --install       -> register & start Windows service (admin)
//   lab-agent.exe --uninstall     -> stop & remove service (admin)
//   lab-agent.exe --console       -> run worker in foreground for debugging

use anyhow::Result;

mod config;

#[cfg(windows)]
mod capture;
#[cfg(windows)]
mod encoder;
#[cfg(windows)]
mod snapshot;
#[cfg(windows)]
mod apps;
#[cfg(windows)]
mod network;
#[cfg(windows)]
mod service;
#[cfg(windows)]
mod worker;

fn main() -> Result<()> {
    env_logger::Builder::from_env(env_logger::Env::default().default_filter_or("info")).init();

    let args: Vec<String> = std::env::args().collect();
    let mode = args.get(1).map(|s| s.as_str()).unwrap_or("");

    #[cfg(windows)]
    {
        match mode {
            "--install"   => service::install()?,
            "--uninstall" => service::uninstall()?,
            "--worker"    => tokio::runtime::Runtime::new()?.block_on(worker::run())?,
            "--console"   => tokio::runtime::Runtime::new()?.block_on(worker::run())?,
            _             => service::run_service_dispatcher()?,
        }
    }

    #[cfg(not(windows))]
    {
        eprintln!("lab-agent is Windows-only. Use --console mode is available only on Windows.");
        let _ = mode;
    }

    Ok(())
}
