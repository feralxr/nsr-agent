# Lab Monitor

LAN screen-monitoring system for a computer lab. Every lab PC runs a hidden
Windows service that streams its display over the LAN to a small relay
server; you open a browser to that server and see every online PC in a
grid, click one, watch it live.

```
┌──────────────┐  H.264 over WS   ┌──────────────┐   H.264 over WS   ┌──────────────┐
│  lab PC #1   │─────────────────▶│              │──────────────────▶│              │
│  lab PC #2   │─────────────────▶│  server      │──────────────────▶│  viewer      │
│  lab PC #N   │─────────────────▶│  (static IP) │──────────────────▶│  (browser)   │
└──────────────┘                  └──────────────┘                   └──────────────┘
   Rust agent                     Node/Bun relay                     TanStack Start
   (Win service)                  + serves viewer                    web app
```

## Repo layout

```
lab-monitor/
├── src/               Viewer web UI (TanStack Start)
├── server/            Node/Bun relay server
└── client/            Rust Windows agent
```

## One-time lab setup

1. **Pick the server PC** and give it a static LAN IP (DHCP reservation
   on the router is easiest). Example: `192.168.1.10`.
2. **Build the viewer** (any machine with Bun):
   ```
   bun install
   bun run build            # produces ./dist
   ```
3. **Start the server** on the static-IP PC:
   ```
   cd server && bun install && bun run start
   ```
   Now `http://192.168.1.10:8080/` shows the (empty) dashboard.
4. **Build the client agent** on any Windows box with Rust + MSVC:
   ```
   cd client
   copy config.template.json config.json
   # edit config.json → set "server": "192.168.1.10"
   cargo build --release
   ```
   → `client/target/release/lab-agent.exe`
5. **Install on each lab PC** (admin PowerShell):
   ```
   mkdir "C:\Program Files\LabAgent"
   copy lab-agent.exe   "C:\Program Files\LabAgent\"
   copy config.json     "C:\Program Files\LabAgent\"
   & "C:\Program Files\LabAgent\lab-agent.exe" --install
   ```
   Or wrap it in an MSI (`cargo wix` in `client/`) and double-click.

## What you get

- Auto-start on boot (Windows service, `LocalSystem`).
- Hard-to-kill (non-admin can't stop the service; SCM auto-recovery
  restarts it after 1s if it crashes; session supervisor re-spawns the
  worker when the user logs out and back in).
- No loading-cursor artifact — uses Windows Graphics Capture, not GDI.
- Near-zero idle CPU — only encodes when a viewer is actually watching.
- 1080p60 @ ~3 Mbps per active stream over LAN.

See each subfolder's `README.md` for details.
