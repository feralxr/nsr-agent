
# Lab Screen Monitoring System

## What we're building

Three components, one repo:

```
lab-monitor/
├── client/          Rust — Windows agent (.exe + installer)
├── server/          Node.js — relay + static host
└── viewer/          This Lovable project — web UI served by server
```

**Flow:** Client PCs run a hidden Windows Service that opens a WebSocket to the server. When you open the viewer in a browser and click a PC, the server tells that client to start H.264-encoding its screen and relays frames to your browser.

## Component 1 — Rust client agent (you compile locally)

**Screen capture:** `windows-capture` crate → Windows Graphics Capture API (WGC). This is the fix for your loading-cursor bug — WGC is invisible to the user, unlike GDI `BitBlt`. Hardware-accelerated, 60fps trivial.

**Encoding:** `openh264` or Media Foundation H.264 encoder via `windows` crate → NVENC/QuickSync when available, software fallback otherwise. Target: 1080p60 @ ~3 Mbps.

**Transport:** `tokio-tungstenite` WebSocket to `ws://<SERVER_IP>:8080/agent`. Sends binary H.264 NAL units. Only encodes when server sends `start_stream` — idle CPU near zero.

**Reconnect loop:** exponential backoff 1s → 30s max, forever. Reads `SERVER_IP` from `config.json` next to the exe (baked at build time, editable post-install).

**Windows Service + watchdog (kill resistance):**
- Two services install together: `LabAgent` and `LabAgentWatchdog`
- Both run as `LocalSystem` (Task Manager can't kill without admin + UAC)
- Service recovery: restart after 1s on failure (built-in Windows feature)
- Watchdog polls `LabAgent` every 5s, restarts it if stopped
- `LabAgent` polls watchdog too — mutual revival
- Also registered in `HKLM\...\Run` as third fallback
- Session 0 isolation: capture runs in user session via a helper process the service spawns per active session (needed because services can't capture user desktops directly)

**Installer:** `cargo-wix` produces a signed-ready `.msi` that:
1. Copies files to `C:\Program Files\LabAgent\`
2. Registers both services with auto-start
3. Starts them immediately
Requires admin UAC once. Uninstall via standard Add/Remove Programs (you can lock this down with a group policy later).

**Config file (`config.json`):**
```json
{ "server": "192.168.1.10", "port": 8080, "client_id": "auto" }
```
`client_id: "auto"` → uses machine hostname.

## Component 2 — Node.js relay server (you run on static-IP PC)

Single `server.js`:
- HTTP server serves the built viewer (`viewer/dist/`)
- WebSocket `/agent` — client agents connect here, register hostname + IP
- WebSocket `/viewer` — browser viewers connect here
- Router: when viewer subscribes to `client_id`, server sends `start_stream` to that agent and pipes frames back to that viewer. Multiple viewers on one client = single encode, fan-out.
- REST `GET /api/clients` → list of online agents (hostname, IP, connected_at)

Packaged as a single-binary with `pkg` or `bun build --compile` so you can run it as a Windows tray app via NSSM or just `bun server.js`.

## Component 3 — Viewer web UI (Lovable builds this)

Since we're inside a Lovable TanStack Start project, I'll build the viewer here and export `viewer/dist/` for the server to serve. But the viewer needs to talk to *your* relay server on the LAN — not to Lovable Cloud. So Lovable Cloud stays disabled.

**Pages:**
- `/` — grid of online PCs (hostname, IP, "last seen") with live-refresh via WebSocket. Click a card → `/view/$clientId`.
- `/view/$clientId` — single H.264 `<video>` element fed via Media Source Extensions from the WebSocket stream. Shows FPS + bitrate overlay.
- Simple settings dialog to set the server URL (persisted in `localStorage`); defaults to same-origin so if you open the viewer at `http://192.168.1.10:8080/` it just works.

**Design:** dark UI, dense grid, monospace hostnames, minimal chrome. Nothing purple/AI-generic.

## Setup you do once per lab

1. Pick a lab PC to be the server. Set its LAN IP static (e.g. `192.168.1.10`) via router DHCP reservation or Windows adapter settings.
2. Edit `client/config.template.json` → `"server": "192.168.1.10"`.
3. Build: `cd client && cargo build --release && cargo wix` → produces `LabAgent-x64.msi`.
4. Run the MSI on each lab PC (admin, one UAC prompt).
5. On the server PC: `bun install && bun run server.js` (or install as a service with NSSM).
6. Open `http://192.168.1.10:8080/` from any browser on the LAN → see all PCs.

## What I'll do now in this Lovable project

- Scaffold the viewer web UI (routes, WebSocket client, MSE video player, PC grid) — this runs in the current TanStack Start project.
- Create `client/` and `server/` folders with complete source code (Rust + Node.js) + a top-level `README.md` with the exact build commands for both.
- You'll download/clone the project, then compile the Rust client on any Windows box with `rustup` installed (~2 min build).

## Technical notes / risks

- **`windows-capture` requires Win10 1803+** — you said Win10/11, so we're fine.
- **Windows Service capturing user desktop:** services live in Session 0 and can't grab user desktops directly. Standard solution (which I'll implement): the service uses `WTSQueryUserToken` + `CreateProcessAsUser` to spawn a helper in the active user session; helper does the capture, pipes frames back to the service over a named pipe, service ships them over the network.
- **H.264 encoder licensing:** Media Foundation's built-in H.264 encoder is free to use on Windows. `openh264` is Cisco-licensed but free for our use.
- **Antivirus:** unsigned services that hide from Task Manager can trigger Defender heuristics. Mitigations: don't hide the process (just make it hard to kill), sign the binary if you have a cert, or add a Defender exclusion via GPO. On self-owned infra this is manageable.
- **Cursor bug:** definitively fixed by using WGC instead of GDI.

Ready to build. On approval I'll scaffold the viewer + drop the full Rust and Node.js source into `client/` and `server/`.
